<?php
// deobfuscate.php
// Usage: php scripts/deobfuscate.php
// Safety: This script only decodes and writes text; it does not execute the decoded PHP code.

set_time_limit(0);

$root = __DIR__ . '/..';
$root = realpath($root);
if ($root === false) $root = getcwd();

$outDir = $root . DIRECTORY_SEPARATOR . 'deobf';
@mkdir($outDir, 0755, true);

$extensions = ['php'];
$files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));
$checked = 0;
$found = 0;

function is_printable_byte($b) {
    $ord = ord($b);
    if ($ord === 9 || $ord === 10 || $ord === 13) return true;
    return ($ord >= 32 && $ord <= 126);
}

function try_decoders($payload) {
    $res = [];

    $decoders = [];
    $decoders[] = ['name'=>'bzdecompress', 'fn'=>function($d){ return function_exists('bzdecompress') ? @bzdecompress($d) : false; }];
    $decoders[] = ['name'=>'gzuncompress', 'fn'=>function($d){ return function_exists('gzuncompress') ? @gzuncompress($d) : false; }];
    $decoders[] = ['name'=>'gzinflate', 'fn'=>function($d){ return function_exists('gzinflate') ? @gzinflate($d) : false; }];
    $decoders[] = ['name'=>'raw', 'fn'=>function($d){ return $d; }];

    foreach ($decoders as $dec) {
        $out = $dec['fn']($payload);
        if ($out !== false && is_string($out) && preg_match('/\<\?php|\bfunction\b|\becho\b|\$[a-zA-Z_]/i', $out)) {
            $res[] = ['method'=>$dec['name'], 'result'=>$out];
        }
    }

    if (preg_match('/^[A-Za-z0-9+\\/\\r\\n\\t]{100,}={0,2}$/s', $payload) || preg_match('/[A-Za-z0-9+\\/]{200,}={0,2}/', $payload)) {
        $b = @base64_decode($payload, true);
        if ($b !== false) {
            $dec2 = [
                ['name'=>'base64->bzdecompress','fn'=>function($d){ return function_exists('bzdecompress') ? @bzdecompress($d) : false; }],
                ['name'=>'base64->gzuncompress','fn'=>function($d){ return function_exists('gzuncompress') ? @gzuncompress($d) : false; }],
                ['name'=>'base64->gzinflate','fn'=>function($d){ return function_exists('gzinflate') ? @gzinflate($d) : false; }],
                ['name'=>'base64->raw','fn'=>function($d){ return $d; }],
            ];
            foreach ($dec2 as $dec) {
                $out = $dec['fn']($b);
                if ($out !== false && is_string($out) && preg_match('/\<\?php|\bfunction\b|\becho\b|\$[a-zA-Z_]/i', $out)) {
                    $res[] = ['method'=>$dec['name'], 'result'=>$out];
                }
            }
        }
    }

    $combos = [
        ['name'=>'gzinflate->base64->gzinflate','fn'=>function($d){
            $a = @gzinflate($d); if ($a === false) return false;
            $b = @base64_decode($a, true); if ($b === false) return false;
            return @gzinflate($b);
        }],
    ];
    foreach ($combos as $c) {
        $out = $c['fn']($payload);
        if ($out !== false && is_string($out) && preg_match('/\<\?php|\bfunction\b|\becho\b|\$[a-zA-Z_]/i', $out)) {
            $res[] = ['method'=>$c['name'], 'result'=>$out];
        }
    }

    return $res;
}

foreach ($files as $f) {
    if (!$f->isFile()) continue;
    $path = $f->getRealPath();
    if (strpos($path, DIRECTORY_SEPARATOR . 'deobf' . DIRECTORY_SEPARATOR) !== false) continue;
    if (strpos($path, DIRECTORY_SEPARATOR . '.git' . DIRECTORY_SEPARATOR) !== false) continue;
    $ext = pathinfo($path, PATHINFO_EXTENSION);
    if (!in_array(strtolower($ext), $extensions)) continue;

    $checked++;
    $content = @file_get_contents($path);
    if ($content === false) continue;

    $len = strlen($content);
    $start = null;
    for ($i = 0; $i < $len; $i++) {
        $c = $content[$i];
        if (!is_printable_byte($c)) {
            $start = $i;
            break;
        }
    }

    $candidates = [];

    if ($start !== null) {
        $payload = substr($content, $start);
        $candidates[] = ['name'=>'binary-trimmed', 'payload'=>$payload, 'offset'=>$start];
    }

    if (preg_match_all('/([A-Za-z0-9+\\/\\r\\n]{200,}={0,2})/s', $content, $matches)) {
        foreach ($matches[1] as $m) {
            $candidates[] = ['name'=>'base64-matched', 'payload'=>$m, 'offset'=>strpos($content, $m)];
        }
    }

    if (count($candidates) === 0) {
        continue;
    }

    $successful = [];
    foreach ($candidates as $cand) {
        $decodes = try_decoders($cand['payload']);
        foreach ($decodes as $d) {
            $successful[] = [
                'candidate'=>$cand['name'],
                'offset'=>$cand['offset'],
                'method'=>$d['method'],
                'result'=>$d['result'],
            ];
        }
    }

    if (count($successful) > 0) {
        $found++;
        $rel = substr($path, strlen($root));
        $rel = ltrim($rel, DIRECTORY_SEPARATOR);
        $baseOutPath = $outDir . DIRECTORY_SEPARATOR . $rel . '.deob';
        @mkdir(dirname($baseOutPath), 0755, true);

        foreach ($successful as $idx => $suc) {
            $outPath = $baseOutPath . ($idx ? '.' . $idx : '') . '.php';
            $header = "<?php\n/**\n * deobfuscated from: {$rel}\n * candidate: {$suc['candidate']}\n * offset: {$suc['offset']}\n * method: {$suc['method']}\n * generated: " . date('c') . "\n */\n\n";
            $body = $suc['result'];
            if (strpos($body, '<?php') === false) {
                $body = "<?php\n" . $body;
            }
            file_put_contents($outPath, $header . $body);
            echo "[OK] wrote: $outPath  (method={$suc['method']})\n";
        }
    } else {
        $rel = substr($path, strlen($root));
        $diagPath = $outDir . DIRECTORY_SEPARATOR . 'diag' . DIRECTORY_SEPARATOR . $rel . '.txt';
        @mkdir(dirname($diagPath), 0755, true);
        $diag = "File: $rel\nChecked candidates: " . count($candidates) . "\n";
        foreach ($candidates as $c) {
            $diag .= "- candidate: {$c['name']} offset={$c['offset']} length=" . strlen($c['payload']) . "\n";
        }
        file_put_contents($diagPath, $diag);
        echo "[..] no decode for: $rel (diagnostic at $diagPath)\n";
    }
}

echo "Done. Checked $checked php files, found decodable payloads in $found files.\n";
?>