<?php
// deobfuscate2.php
// Enhanced deobfuscation attempts: scans binary payloads for bzip2/gzip headers,
// tries decompression from those offsets, tries base64 decoding with cleaning,
// and attempts single-byte XOR heuristics for detecting '<?php'.
// Usage: php scripts/deobfuscate2.php

set_time_limit(0);

$root = isset($argv[1]) ? $argv[1] : (__DIR__ . '/..');
$root = realpath($root) ?: getcwd();
$outDir = isset($argv[2]) ? $argv[2] : ($root . DIRECTORY_SEPARATOR . 'deobf2');
@mkdir($outDir, 0755, true);
$extensions = ['php'];
$files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));

function is_printable_byte($b) {
    $ord = ord($b);
    if ($ord === 9 || $ord === 10 || $ord === 13) return true;
    return ($ord >= 32 && $ord <= 126);
}

function looks_like_php($s) {
    return is_string($s) && preg_match('/<\?php|\bfunction\b|\becho\b|\$[a-zA-Z_]/i', $s);
}

function try_bz_from_offsets($payload) {
    $res = [];
    $len = strlen($payload);
    for ($i = 0; $i < $len; $i++) {
        // look for 'BZ' or 'BZh' header
        if ($payload[$i] === 'B' && ($i+1 < $len) && $payload[$i+1] === 'Z') {
            $chunk = substr($payload, $i);
            if (function_exists('bzdecompress')) {
                $out = @bzdecompress($chunk);
                if ($out !== false && looks_like_php($out)) {
                    $res[] = ['offset'=>$i, 'method'=>'bzdecompress', 'result'=>$out];
                }
            }
        }
    }
    return $res;
}

function try_gz_from_offsets($payload) {
    $res = [];
    $len = strlen($payload);
    for ($i=0;$i<$len;$i++){
        // gzip header 0x1f 0x8b 0x08
        if ($i+2 < $len && ord($payload[$i])===0x1f && ord($payload[$i+1])===0x8b && ord($payload[$i+2])===0x08) {
            $chunk = substr($payload,$i);
            if (function_exists('gzdecode')) {
                $out = @gzdecode($chunk);
                if ($out !== false && looks_like_php($out)) {
                    $res[]=['offset'=>$i,'method'=>'gzdecode','result'=>$out];
                }
            }
            if (function_exists('gzinflate')) {
                // sometimes stored as zlib without extra header
                $out2 = @gzinflate($chunk);
                if ($out2 !== false && looks_like_php($out2)) {
                    $res[]=['offset'=>$i,'method'=>'gzinflate','result'=>$out2];
                }
            }
        }
    }
    return $res;
}

function try_base64_clean_then_decompress($payload) {
    $res = [];
    // extract long base64-like substrings
    if (preg_match_all('/([A-Za-z0-9+\/\\r\\n=]{200,})/s', $payload, $m)) {
        foreach ($m[1] as $b64) {
            $clean = preg_replace('/[^A-Za-z0-9+\/=]/', '', $b64);
            $decoded = @base64_decode($clean, true);
            if ($decoded !== false) {
                if (looks_like_php($decoded)) {
                    $res[]=['method'=>'base64->raw','result'=>$decoded];
                }
                // try decompressors
                if (function_exists('bzdecompress')) {
                    $bz = @bzdecompress($decoded);
                    if ($bz !== false && looks_like_php($bz)) $res[]=['method'=>'base64->bzdecompress','result'=>$bz];
                }
                if (function_exists('gzdecode')) {
                    $gz = @gzdecode($decoded);
                    if ($gz !== false && looks_like_php($gz)) $res[]=['method'=>'base64->gzdecode','result'=>$gz];
                }
                if (function_exists('gzinflate')) {
                    $inf = @gzinflate($decoded);
                    if ($inf !== false && looks_like_php($inf)) $res[]=['method'=>'base64->gzinflate','result'=>$inf];
                }
            }
        }
    }
    return $res;
}

function try_simple_xor($payload, $max_scan=8192) {
    // Try single-byte XOR keys on the first max_scan bytes to detect '<?php'
    $res = [];
    $len = strlen($payload);
    $scan = substr($payload, 0, min($max_scan, $len));
    for ($k=1; $k<256; $k++) {
        $decoded = $scan ^ str_repeat(chr($k), strlen($scan));
        if (strpos($decoded, '<?php') !== false || preg_match('/<\?php|function\s+\w+/', $decoded)) {
            // try full payload XOR
            $full = $payload ^ str_repeat(chr($k), $len);
            if (looks_like_php($full)) {
                $res[]=['method'=>'xor','key'=>$k,'result'=>$full];
            }
        }
    }
    return $res;
}

foreach ($files as $f) {
    if (!$f->isFile()) continue;
    $path = $f->getRealPath();
    if (strpos($path, DIRECTORY_SEPARATOR . 'deobf2' . DIRECTORY_SEPARATOR) !== false) continue;
    if (strpos($path, DIRECTORY_SEPARATOR . '.git' . DIRECTORY_SEPARATOR) !== false) continue;
    $ext = pathinfo($path, PATHINFO_EXTENSION);
    if (!in_array(strtolower($ext), $extensions)) continue;

    $content = @file_get_contents($path);
    if ($content === false) continue;

    $len = strlen($content);
    $start = null;
    for ($i=0;$i<$len;$i++) {
        $c = $content[$i];
        if (!is_printable_byte($c)) { $start = $i; break; }
    }
    if ($start === null) continue;
    $payload = substr($content, $start);
    $results = [];

    // direct raw check
    if (looks_like_php($payload)) {
        $results[]=['method'=>'raw','result'=>$payload];
    }

    // try bzip offsets
    $results = array_merge($results, try_bz_from_offsets($payload));
    $results = array_merge($results, try_gz_from_offsets($payload));
    $results = array_merge($results, try_base64_clean_then_decompress($payload));
    // try XOR heuristics (slow) for all files; scan limited to first 8KB
    $results = array_merge($results, try_simple_xor($payload, 8192));
    $rel = ltrim(substr($path, strlen($root)), DIRECTORY_SEPARATOR);
    // XLOAD detection
    if (preg_match('/extension_loaded\(["\']XLOAD["\']\)\s+and\s+\d+\s+or\s+exit\(/', $content)) {
        $diagPath = $outDir . DIRECTORY_SEPARATOR . 'diag' . DIRECTORY_SEPARATOR . $rel . '.txt';
        @mkdir(dirname($diagPath), 0755, true);
        $diag = "File: $rel\nXLOAD encrypted (requires XLOAD extension, cannot be statically decrypted)\n";
        file_put_contents($diagPath, $diag);
        echo "[..] XLOAD detected for $rel (cannot statically decrypt)\n";
        continue;
    }
    if (count($results) > 0) {
        foreach ($results as $idx=>$r) {
            $outPath = $outDir . DIRECTORY_SEPARATOR . $rel . '.deob.' . $idx . '.php';
            @mkdir(dirname($outPath), 0755, true);
            $header = "<?php\n/**\n * enhanced deobfuscated from: {$rel}\n * method: {$r['method']}";
            if (isset($r['key'])) $header .= "; key={$r['key']}";
            $header .= "\n * generated: " . date('c') . "\n */\n\n";
            $body = $r['result'];
            if (strpos($body, '<?php') === false) $body = "<?php\n" . $body;
            file_put_contents($outPath, $header . $body);
            echo "[OK] wrote $outPath\n";
        }
    } else {
        $diagPath = $outDir . DIRECTORY_SEPARATOR . 'diag' . DIRECTORY_SEPARATOR . $rel . '.txt';
        @mkdir(dirname($diagPath), 0755, true);
        $diag = "File: $rel\nstart={$start}\nlen_payload=" . strlen($payload) . "\nno successful decode attempts\n";
        file_put_contents($diagPath, $diag);
        echo "[..] no decode for $rel (diag saved)\n";
    }
}

echo "Done.\n";
