# PHP 反混淆工具链 (phpdec)

针对「PHP 二次混淆（加密壳 + 控制流平坦化）」的还原工具链。该工具链用于还原 LAN朋友圈 v4.6 项目的混淆代码，对类似混淆手法的 PHP 项目可复用。

## 依赖

- Python 3.8+
- PHP CLI（用于 `php -l` 语法验证）

## 处理对象

本工具链针对以下两类混淆技术：

1. **加密壳**：`function (XUF 类乱码函数)(&$out,$key,$seed)` 内通过 `$res .= $str[$i] ^ $key[$j]` 逐字节异或解密字符串，配合 `eval(base64_decode(...))` 动态执行。
2. **控制流平坦化**：`$L2xBuEtN=array(); ... [] = k` 常数表 + `$L2xOiRyN=<哨兵>` 状态变量 + `if(条件) goto T; goto F;` 判定矩阵 + 大量 label。

## 流程

```
混淆 PHP 源码
   │
   ▼ 步骤1：剥壳 (batch3.py)
   │        检测 XOR 解密壳 + eval 动态执行点，注入 file_put_contents
   │        导出运行时解密结果 → *.xor / *.body
   │
   ▼ 步骤2：手动整理为 *.dec.php（第一层解密后源码）
   │
   ▼ 步骤3：控制流还原 (deobf_core.py / full_batch.py)
   │        常数表内联、数值传播、判定折叠、goto 化简、死代码删除
   │        → *.deobf.php
   │
   ▼ 步骤4：清理 (cleanup2.py)
   │        哨兵分发简化、call_user_func_array 转换、死变量删除
   │        → 最终可读源码
   │
   ▼ 步骤5：验证 (php -l + verify_semantics.py)
```

## 工具说明

| 脚本 | 功能 | 用法 |
|------|------|------|
| `batch3.py` | 剥壳：检测加密壳并注入 dump 代码 | `python3 batch3.py <SRC目录> <输出目录> <dump输出目录>` |
| `deobf_core.py` | 核心还原引擎：控制流平坦化还原 | `python3 deobf_core.py <输入.dec.php> <输出.deobf.php>` |
| `full_batch.py` | 批量还原 + `php -l` 验证 | `python3 full_batch.py <dec目录> <输出目录>` |
| `cleanup2.py` | 阶段2清理：简化哨兵分发、转换动态调用 | `python3 cleanup2.py '<glob 路径>'` |
| `verify_semantics.py` | 语义等价验证：对比还原前后调用/goto/label 集合 | `python3 verify_semantics.py <还原前目录> <还原后目录>` |

## 快速开始

```bash
# 1. 剥壳：扫描源码目录，注入运行时 dump
python3 batch3.py /path/to/project wc out

# 2. 执行被注入的 PHP 文件，收集 *.xor 解密结果
#    （需在 PHP 环境中运行注入后的文件）

# 3. 根据 dump 结果整理出第一层解密源码 *.dec.php

# 4. 批量控制流还原 + 语法检查
python3 full_batch.py decrypted clean2

# 5. 阶段2清理
python3 cleanup2.py 'clean2/*.deobf.php'

# 6. 语义验证
python3 verify_semantics.py pre_reduce clean2
```

## 还原效果（实测）

以 LAN朋友圈 v4.6 为例，62 个混淆文件全部还原并通过 `php -l`：

| 指标 | 混淆后 | 还原后 | 缩减率 |
|------|--------|--------|--------|
| goto | 11811 | 1983 | 83.2% |
| label | 19074 | 6839 | 64.1% |
| cjump2 | 3908 | 1116 | 71.4% |
| 总控制流 | 30885 | 9938 | 67.8% |

## 免责声明

本工具链仅用于授权范围内的代码审计、恶意软件分析、以及混淆代码可读性研究。请勿用于非法用途。
