#!/usr/bin/env python3
"""goto 消除器 v1：块递归 + cjump 配对还原
处理 deobf_core 结构化后残留在 if{}/else{}/while{}/bare-block 内部及顶层的 goto。

核心思路：
  - 用词法扫描切出块边界（跳过字符串/注释），得到"块内语句行"
  - 块内 tokenize（label/jump/cjump2/stmt，语义同 deobf_core.Tokenizer）
  - 逐模式还原 goto：
      P1  相邻 jump+label 消除   goto X; X:
      P2  独立 if goto           if(cond)goto T; goto F; T: <body, 无跳出> ; 其余为 F 流
                                   -> if(cond){ body }
      P3  共享合并点 if/else    与 P2 类似, 但 body 以 goto M 结尾且后接 F body 以 M 收束
                                   -> if(cond){ body }else{ fbody }
  保守守则: 任何 body 若含 label 被外部引用 / goto 目标在块外 / 配对含歧义,
           则不重写该块（保持原样）。
"""
import re, sys, collections

# ---------- 词法 ----------
ST  = re.compile(r'\s*([A-Za-z_]\w*)\s*:\s*$')          # 纯 label 行
GOL = re.compile(r'^\s*goto\s+([A-Za-z_]\w*)\s*;?\s*$') # goto X;
IGL = re.compile(r'^\s*if\s*\(\s*(.*?)\s*\)\s*goto\s+([A-Za-z_]\w*)\s*;?\s*$')  # if(cond)goto T;

def split_stmts(code):
    """按行切 + 端末分号归并（极简：保留每行，供块递归用）"""
    return code.split('\n')

def brace_depth_of_line(line, instr_pair=(False, '')):
    """返回(净括号增量, 是否新增跨行字符串)。不解析字符串内括号。"""
    pass

def scan_blocks(lines):
    """输入行列表，输出 (chunks, ends): 每行所属块层级 & 块闭合位置。
    return items: list of (level, line_idx) 用于决定在哪些层递归。
    简化: 本实现直接在 line 级用栈处理，找出顶层语句序列。
    """
    out = []       # (kind, payload, line_start, line_end)
    depth = 0
    instr = False
    quote = ''
    i = 0
    n = len(lines)
    cur_start = 0
    while i < n:
        line = lines[i]
        j = 0
        m = len(line)
        # 词法扫描该行，关注 { } 与 if(...){/else{ 的结构
        head = line.lstrip()
        if depth == 0:
            if head.startswith('if('):
                # 找到 { 或 goto; 同栈处理
                pass
        # 简单括号统计
        d = 0
        instr2 = instr
        qt2 = quote
        k = 0
        while k < m:
            ch = line[k]
            if instr2:
                if ch == '\\':
                    k += 2
                    continue
                if ch == qt2:
                    instr2 = False
                k += 1
                continue
            if ch == "'" or ch == '"':
                instr2 = True
                qt2 = ch
                k += 1
                continue
            if ch == '{':
                d += 1
            elif ch == '}':
                d -= 1
            k += 1
        instr = instr2
        quote = qt2
        # 未变体：这里 d 是整行净增量，不够细粒度，需行内定位首个 '{'
        new_depth = depth + d
        # 目标：标注每行结束后 depth。
        i += 1
    return out

def tokenize_block(lines):
    """块内行 -> token 序列。
    token 类型: ('label', name) ('jump', name) ('cjump2',(cond,T,F)) ('stmt', text)
    cjump2 = if(cond)goto T; goto F; 紧邻合并."""
    toks = []
    for s in lines:
        t = s.strip()
        if not t:
            continue
        m = re.match(r'([A-Za-z_]\w*)\s*:\s*$', t)
        if m:
            toks.append(('label', m.group(1)))
            continue
        m = GOL.match(t)
        if m:
            toks.append(('jump', m.group(1)))
            continue
        m = IGL.match(t)
        if m:
            toks.append(('cjump', (m.group(1), m.group(2))))
            continue
        toks.append(('stmt', s))
    # 合并 cjump+紧跟 jump -> cjump2 (cond,T,F)
    out = []
    i = 0
    n = len(toks)
    while i < n:
        k, p = toks[i]
        if k == 'cjump':
            cond, T = p
            F = None
            if i + 1 < n and toks[i + 1][0] == 'jump':
                F = toks[i + 1][1]
                out.append(('cjump2', (cond, T, F)))
                i += 2
                continue
            out.append(toks[i])
            i += 1
            continue
        out.append(toks[i])
        i += 1
    return out


def count_refs(toks):
    """label -> 引用的 goto 次数 (仅统计 jump/cjump2 的 target)"""
    refs = collections.Counter()
    for k, p in toks:
        if k == 'jump':
            refs[p] += 1
        elif k == 'cjump2':
            refs[p[1]] += 1
            refs[p[2]] += 1
    return refs


def find_label(toks, i, name):
    """从 i 起找首个 name label 的 index, 找不到返回 None"""
    for j in range(i, len(toks)):
        if toks[j][0] == 'label' and toks[j][1] == name:
            return j
    return None


def render(toks, base_indent=''):
    """token -> 行文本"""
    ls = []
    for k, p in toks:
        if k == 'label':
            ls.append(p + ':')
        elif k == 'jump':
            ls.append('goto ' + p + ';')
        elif k == 'cjump2':
            cond, T, F = p
            ls.append('if(' + cond + ')goto ' + T + ';')
            ls.append('goto ' + F + ';')
        elif k == 'stmt':
            ls.append(p)
    return ls


def recurse_nested(lines):
    """深度消除: 切块 → 块内递归消 goto → 本层 P1/P2 模式消 goto.
    P3 死 label 清理在顶层统一执行(跨块引用安全)."""
    return p3_deadlabel_clean(_recurse_inner(lines))


def _recurse_inner(lines):
    """递归内部版本, 不做 P3."""
    out = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        trim = line.strip()
        is_block = (
            (trim.startswith('if(') and trim.rstrip().endswith('{')) or
            trim.startswith('else{') or
            trim.startswith('while(') and trim.rstrip().endswith('{') or
            trim.startswith('foreach(') and trim.rstrip().endswith('{') or
            trim.startswith('switch(') and trim.rstrip().endswith('{')
        )
        if is_block:
            endi = find_block_end(lines, i)
            if endi is not None:
                inner = _recurse_inner(lines[i + 1:endi])
                out.append(line)
                out.extend(inner)
                is_else_conn = '}else' in lines[endi] and lines[endi].rstrip().endswith('{')
                if not is_else_conn:
                    out.append(lines[endi])
                j0 = endi
                while j0 < n and '}else' in lines[j0] and lines[j0].rstrip().endswith('{'):
                    eendi = find_block_end(lines, j0)
                    if eendi is None:
                        break
                    inner2 = _recurse_inner(lines[j0 + 1:eendi])
                    out.append(lines[j0])
                    out.extend(inner2)
                    out.append(lines[eendi])
                    j0 = eendi
                i = j0 + 1
                continue
        out.append(line)
        i += 1
    return eliminate_seq(out)


def eliminate_seq(lines):
    """对一行序列执行 P1(相邻) / P2(单分支) 模式消除, 返回消除后行列表."""
    toks = tokenize_block(lines)
    refs = count_refs(toks)
    n = len(toks)
    out = []
    i = 0
    changed = False
    while i < n:
        k, p = toks[i]
        if k == 'jump':
            # P1: goto X; X: (相邻)
            if i + 1 < n and toks[i + 1][0] == 'label' and toks[i + 1][1] == p:
                out.append(('label', p))  # 保留 label（可能有外部引用）
                i += 2
                changed = True
                continue
            out.append(toks[i]); i += 1; continue
        if k == 'cjump2':
            cond, T, F = p
            # P1.5: F label 紧跟其后 → goto F 是 fallthrough, 只保留 if(cond)goto T 与 F label
            if i + 1 < n and toks[i + 1][0] == 'label' and toks[i + 1][1] == F:
                out.append(('stmt', 'if(' + cond + ')goto ' + T + ';'))
                out.append(('label', F))
                i += 2
                changed = True
                continue
            ti = find_label(toks, i + 1, T)
            if ti is not None:
                # 守卫: i 与 ti 之间不得有别的转移/label (case 链跳过)
                has_gap = False
                for mm in range(i + 1, ti):
                    if toks[mm][0] in ('cjump', 'cjump2', 'jump', 'label'):
                        has_gap = True
                        break
                if has_gap:
                    out.append(toks[i]); i += 1; continue
                # 收集 T body: [ti+1, 终止) 终止点: jump / F label / 块尾
                body = []
                j = ti + 1
                while j < n:
                    if toks[j][0] == 'jump':
                        Mj = j
                        break
                    if toks[j][0] == 'label' and toks[j][1] == F:
                        Mj = j
                        break
                    body.append(toks[j])
                    j += 1
                else:
                    Mj = n
                # T 引用数==1 且 body 无转移 → 可安全还原
                body_is_simple = refs.get(T, 0) == 1
                for bk, bp in body:
                    if bk in ('jump', 'cjump', 'cjump2', 'label'):
                        body_is_simple = False
                        break
                if body_is_simple and Mj < n:
                    if Mj == ti + 1:
                        out.append(toks[i]); i += 1; continue
                    fm = toks[Mj]
                    # P2-FULL: F 有独立 body 且 F 仅本 transfer 引用 → 还原 if/else
                    # 判据: T..F 之间无其它 label 且 F 到下一 label 为纯语句
                    fi = find_label(toks, ti + 1, F)
                    if fi is not None and refs.get(F, 0) == 1:
                        between_labels = any(
                            toks[mm][0] == 'label' for mm in range(ti + 1, fi))
                        if not between_labels:
                            # Fbody = toks[fi : 下一 label)
                            nxt = None
                            mm = fi + 1
                            while mm < n:
                                if toks[mm][0] == 'label':
                                    nxt = mm
                                    break
                                mm += 1
                            fbody = toks[fi + 1:nxt] if nxt else toks[fi + 1:]
                            fbody_ok = True
                            for bk, bp in fbody:
                                if bk in ('jump', 'cjump', 'cjump2', 'label'):
                                    fbody_ok = False
                                    break
                            if fbody_ok:
                                # body 以 goto M 结尾(M 是本 if/else 后合并点)
                                merged = False
                                if (fm[0] == 'jump' and fm[1] != F):
                                    merged = True
                                elif fm[0] == 'jump' and fm[1] == F:
                                    merged = True
                                    # goto F; F label 跟在 body 后 → else 分支起始
                                    pass
                                # 输出 if(cond){ Tbody } else { Fbody }
                                obody = []
                                for bk, bp in body:
                                    if bk == 'jump' and bp != F:
                                        # 保留跳向合并点的 goto
                                        obody.append(('jump', bp))
                                    else:
                                        obody.append((bk, bp))
                                out.append(('stmt', 'if(' + cond + '){'))
                                out.extend(obody)
                                out.append(('stmt', '}else{'))
                                out.extend(fbody)
                                out.append(('stmt', '}'))
                                # 跳过 goto M 与 F label
                                endpos = fi + 1 if fm[0] == 'label' else fi + 1
                                if fm[0] == 'jump':
                                    endpos = Mj + 1
                                i = max(endpos, fi + 1)
                                # 若 F body 内容为空同 fbody_ok 但 Mj 处可能是 label F
                                while i < n and (toks[i][0] == 'label' and toks[i][1] == F):
                                    i += 1
                                changed = True
                                continue
                    # 回退基础处理
                    if fm[0] == 'jump' and fm[1] == F:
                        out.append(('stmt', 'if(' + cond + '){'))
                        out.extend(body)
                        out.append(('stmt', '}'))
                        i = Mj
                        changed = True
                        continue
                    if fm[0] == 'label' and fm[1] == F:
                        out.append(('stmt', 'if(' + cond + '){'))
                        out.extend(body)
                        out.append(('stmt', '}'))
                        i = Mj
                        changed = True
                        continue
                out.append(toks[i]); i += 1; continue
            out.append(toks[i]); i += 1; continue
        out.append(toks[i]); i += 1
    if changed:
        return render(out)
    return lines


def p3_deadlabel_clean(lines):
    """P3: 删除无任何 goto 引用的纯 label 行（死 label 不影响语义）。
    逐块处理: switch/if 块内的 label 引用可能跨块, 保守仅处理整体无引用的.
    """
    out = list(lines)
    # 迭代: 删除可能级联空引用
    for _ in range(3):
        refs = collections.Counter()
        for l in out:
            for m in re.finditer(r'\bgoto\s+(L2x\w+)', l):
                refs[m.group(1)] += 1
            for m in re.finditer(r'if\((.+?)\)\s*goto\s+(L2x\w+)', l):
                refs[m.group(2)] += 1
        new = []
        changed = False
        for idx, l in enumerate(out):
            m = re.match(r'\s*(L2x\w+):\s*$', l)
            if m and refs.get(m.group(1), 0) == 0:
                prev = new[-1] if new else ''
                nxt = out[idx + 1] if idx + 1 < len(out) else ''
                # 边界守卫: label 前一行为 } 或后一行为 }/else 等块边界都保守保留
                if prev.rstrip().endswith('{'):
                    new.append(l)
                    continue
                if prev.rstrip() == '}':
                    new.append(l)
                    continue
                if nxt.rstrip().startswith('else') or nxt.rstrip() == '}':
                    new.append(l)
                    continue
                changed = True
                continue  # 丢弃死 label 行
            new.append(l)
        out = new
        if not changed:
            break
    return out


def find_block_end(lines, i):
    """从 i 行(含 '{') 开始，用括号计数（跳过字符串）定位匹配的 } 行。
    返回行号; 找不到返回 None."""
    depth = 0
    instr = False
    quote = ''
    n = len(lines)
    first = True
    for j in range(i, n):
        line = lines[j]
        k = 0
        m = len(line)
        while k < m:
            ch = line[k]
            if instr:
                if ch == '\\':
                    k += 2
                    continue
                if ch == quote:
                    instr = False
                k += 1
                continue
            if ch == "'" or ch == '"':
                instr = True
                quote = ch
                k += 1
                continue
            if ch == '{':
                depth += 1
                first = False
            elif ch == '}':
                if first:
                    pass
                else:
                    depth -= 1
                    if depth == 0:
                        return j
            k += 1
    return None


def process_file(text):
    lines = text.split('\n')
    # 深度消除：切块递归 + 每层 P1/P2 模式（含顶层）
    return recurse_nested(lines)


if __name__ == '__main__':
    path = sys.argv[1]
    out_path = sys.argv[2] if len(sys.argv) > 2 else path + '.ge.php'
    text = open(path).read()
    res_lines = process_file(text)
    res = '\n'.join(res_lines)
    open(out_path, 'w').write(res)
    before = len(re.findall(r'\bgoto\s+L2x', text))
    after = len(re.findall(r'\bgoto\s+L2x', res))
    print(f"{path} -> {out_path}: {len(text)} -> {len(res)} bytes; goto {before} -> {after}")
    try:
        import subprocess
        r = subprocess.run(['php', '-l', out_path], capture_output=True, text=True)
        print(r.stdout.strip() or r.stderr.strip())
    except FileNotFoundError:
        pass