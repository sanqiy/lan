"""语义等价性验证：对比还原前后函数/方法调用集合与 goto/label 结构。"""
import re, sys, glob, os

def extract_calls(text):
    calls = set()
    for m in re.finditer(r'(?:->|\b)([A-Za-z_][A-Za-z0-9_]*)\s*\(', text):
        calls.add(m.group(1))
    return calls

def extract_gotos(text):
    return set(re.findall(r'\bgoto\s+(\w+);', text))

def extract_labels(text):
    return set(re.findall(r'^(\w+):', text, re.M))

pre_dir = sys.argv[1] if len(sys.argv) > 1 else 'pre_reduce'
post_dir = sys.argv[2] if len(sys.argv) > 2 else 'clean2'

ok = True
for pre in sorted(glob.glob(os.path.join(pre_dir, '*.deobf.php'))):
    post = os.path.join(post_dir, os.path.basename(pre))
    if not os.path.exists(post):
        print('MISSING: %s' % post)
        ok = False
        continue
    with open(pre) as f: a = f.read()
    with open(post) as f: b = f.read()

    ca, cb = extract_calls(a), extract_calls(b)
    ga, gb = extract_gotos(a), extract_gotos(b)
    la, lb = extract_labels(a), extract_labels(b)

    miss_calls = cb - ca   # 还原后新增的调用 = 异常
    add_calls = ca - cb    # 还原后丢失的调用
    miss_gotos = gb - ga
    add_gotos = ga - gb
    miss_labels = lb - la
    add_labels = la - lb

    problems = []
    if miss_calls:
        problems.append('新增调用: %s' % sorted(miss_calls))
    if miss_gotos:
        problems.append('新增goto: %s' % sorted(miss_gotos))
    if miss_labels:
        problems.append('新增label: %s' % sorted(miss_labels))
    # 丢失的调用：if 结构还原会删掉哨兵检查相关调用吗？不会，调用应只增不减
    if add_calls:
        problems.append('丢失调用: %s' % sorted(add_calls))
    if add_gotos:
        problems.append('丢失goto: %s' % sorted(add_gotos))
    if add_labels:
        problems.append('丢失label: %s' % sorted(add_labels))

    if problems:
        ok = False
        print('%s: %s' % (os.path.basename(post), '; '.join(problems)))

print('ALL OK' if ok else 'ISSUES FOUND')
