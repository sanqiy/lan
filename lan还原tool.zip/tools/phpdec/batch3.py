import os, re, sys
SRC=sys.argv[1] if len(sys.argv)>1 else '.'
DST=sys.argv[2] if len(sys.argv)>2 else 'wc'
OUTDIR=sys.argv[3] if len(sys.argv)>3 else 'out'
os.makedirs(DST,exist_ok=True)
os.makedirs(OUTDIR,exist_ok=True)
patEval=re.compile(rb"if\(strstr\(\$_SERVER\['HTTP_USER_AGENT'\],chr\(46\)\)\)eval\(([^)]+)\);")
xorpat=re.compile(rb"\$([^\x00-\x20;=$\x5f]{1,60})\.=\$[^\[\]$]{1,60}\[[^\]^]{1,30}\]\^\$[^\[\]$]{1,60}\[[^\]^]{1,30}\];")
# XLOAD 检测: extension_loaded('XLOAD') and <N> or exit(...)
xloadpat=re.compile(rb"extension_loaded\('XLOAD'\)\s+and\s+\d+\s+or\s+exit\(")
total=0; done=0; xload=0
for root,dirs,files in os.walk(SRC):
    if '.git' in root: continue
    for fn in files:
        if not fn.endswith('.php'): continue
        full=os.path.join(root,fn); rel=os.path.relpath(full,SRC)
        data=open(full,'rb').read()
        enc=False
        mx=xorpat.search(data)
        if mx:
            resv=mx.group(1)
            resesc=re.escape(resv)
            mout=re.search(rb"\}(\$[^\x00-\x20;$\x5f]{1,60})=\$"+resesc+rb";return \$"+resesc+rb";\}", data)
            if mout:
                outv=mout.group(1).lstrip(b'$')
                enc=True
                key=os.path.join(OUTDIR, rel.replace('/','_').replace('.php','.xor')).encode()
                dump=b"file_put_contents('"+key+b"',$"+resv+b".\"\\n[[[NEXT]]]\\n\",FILE_APPEND);"
                old=b"}$"+outv+b"=$"+resv+b";return $"+resv+b";}"
                new=b"}"+dump+b"$"+outv+b"=$"+resv+b";return $"+resv+b";}"
                data=data.replace(old,new,1)
        m2=patEval.search(data)
        if m2:
            key2=os.path.join(OUTDIR, rel.replace('/','_').replace('.php','.body')).encode()
            data=data[:m2.start()]+b"file_put_contents('"+key2+b"',"+m2.group(1)+b");"+data[m2.end():]
        os.makedirs(os.path.join(DST,os.path.dirname(rel)),exist_ok=True)
        xl=xloadpat.search(data)
        if xl: xload+=1
        open(os.path.join(DST,rel),'wb').write(data)
        total+=1
        if enc: done+=1
msg=f"total={total} encrypted={done}"
if xload: msg+=f" XLOAD={xload}"
print(msg)
