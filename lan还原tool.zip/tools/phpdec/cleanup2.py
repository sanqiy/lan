#!/usr/bin/env python3
"""
Phase 2 cleanup: Simplify sentinel dispatch, convert call_user_func_array,
inline trivial intermediates, fix style issues.
"""
import re, glob

def cleanup_file(path):
    with open(path) as f:
        text = f.read()
    lines = text.split('\n')

    # --- Phase 2a: Simplify sentinel dispatch pattern ---
    # Pattern: $L2xOiRyN=<default>; $L2x8F=<cond>; if($L2x8F){$L2xOiRyN=<val>;};
    #          $L2x8F=<const>; $L2x8G=<val>; $L2x8H=$L2xOiRyN==<val>; if($L2x8H){code};
    # → if(<cond>){code};
    lines = simplify_sentinel(lines)

    # --- Phase 2b: Remove dead sentinel variables after simplification ---
    lines = remove_dead_sentinels(lines)

    # --- Phase 2c: Convert call_user_func_array($obj, $args) patterns ---
    lines = convert_cufa(lines)

    # --- Phase 2d: Fix if(!COND){}else{code} → if(COND){code} ---
    lines = fix_empty_if_not(lines)

    # --- Phase 2e: Inline trivial $L2x* intermediates ---
    lines = inline_trivial_intermediates(lines)

    # --- Phase 2f: Remove unused L2x labels (again after simplification) ---
    text = '\n'.join(lines)
    goto_targets = set(m.group(1) for m in re.finditer(r'\bgoto\s+(L2x\w+)', text))
    def remove_unused_label(m):
        label = m.group(1)
        if label not in goto_targets:
            return ''
        return m.group(0)
    text = re.sub(r'^[ \t]*(L2x\w+):\s*\n', remove_unused_label, text, flags=re.M)

    # --- Phase 2g: Remove stray empty-statement semicolons after blocks ---
    # }; on its own line (with only whitespace) is a harmless empty statement.
    # do-while }while(); keeps the ; on the same line, so this is safe.
    text = re.sub(r'^([ \t]*)\};\s*\n', r'\1}\n', text, flags=re.M)

    # --- Phase 2g2: Remove empty-statement ; after else{ ---
    text = re.sub(r'^([ \t]*)\}else\{;\s*\n', r'\1}else{\n', text, flags=re.M)

    # --- Phase 2h: Apply basic formatting ---
    text = format_code(text)

    # --- Phase 2i: Cleanup whitespace ---
    text = re.sub(r'[ \t]+$', '', text, flags=re.M)
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = text.rstrip('\n') + '\n'

    with open(path, 'w') as f:
        f.write(text)
    return path


def simplify_sentinel(lines):
    """Simplify the $L2xOiRyN sentinel dispatch pattern."""
    # The sentinel pattern has this structure:
    #   $L2xOiRyN = <default>;
    #   $L2x8F = <condition>;
    #   if($L2x8F) { $L2xOiRyN = <val>; };
    #   [optional more conditions]
    #   $L2x8F = <const>;  // reset
    #   $L2x8G = <val>;    // target
    #   $L2x8H = $L2xOiRyN == <val>;  // check
    #   if($L2x8H) { <code> };
    #
    # Simplify to: if(<condition>) { <code> };
    # Only works for single-condition dispatch.

    i = 0
    out = []
    n = len(lines)
    while i < n:
        line = lines[i].strip()

        # Look for: $L2xOiRyN = <default>;
        m = re.match(r'^\$L2xOiRy(\d+)\s*=\s*(\d+);$', line)
        if not m:
            out.append(lines[i])
            i += 1
            continue

        sentinel_name = f'L2xOiRy{m.group(1)}'
        default_val = m.group(2)

        # Collect the sentinel block: sequence of conditional assignments
        j = i + 1
        conditions = {}  # val -> condition expression
        while j < n:
            l = lines[j].strip()

            # Pattern: $L2x8F = <condition>; if($L2x8F) { $L2xOiRyN = <val>; };
            m2 = re.match(r'^\$L2x8F\s*=\s*(.+?);\s*$', l)
            if m2:
                cond = m2.group(1)
                # Check next line(s): if($L2x8F) { $L2xOiRyN = <val>; };
                if j + 1 < n:
                    nl = lines[j + 1].strip()
                    m3 = re.match(r'^if\(\$L2x8F\)\s*\{\s*\$' + sentinel_name + r'\s*=\s*(\d+);\s*\};?$', nl)
                    if m3:
                        val = m3.group(1)
                        conditions[val] = cond
                        j += 2
                        continue
                    # if($L2x8F){  (multi-line)
                    m3 = re.match(r'^if\(\$L2x8F\)\{$', nl)
                    if m3:
                        # Check next line for $L2xOiRyN = <val>;
                        if j + 2 < n:
                            nl2 = lines[j + 2].strip()
                            m4 = re.match(r'^\$' + sentinel_name + r'\s*=\s*(\d+);$', nl2)
                            if m4:
                                val = m4.group(1)
                                # Check for closing };
                                if j + 3 < n and lines[j + 3].strip() in ('};', '}'):
                                    conditions[val] = cond
                                    j += 4
                                    continue
                                if j + 3 < n and lines[j + 3].strip().startswith('}') and j + 4 < n and lines[j + 4].strip() == '};':
                                    conditions[val] = cond
                                    j += 5
                                    continue
            # if($L2x8F){$L2xOiRyN=<val>;};  (one-liner)
            m2 = re.match(r'^if\(\$L2x8F\)\{\s*\$' + sentinel_name + r'\s*=\s*(\d+);\s*\};?$', l)
            if m2:
                val = m2.group(1)
                # Need to find the condition - look back at the previous $L2x8F assignment
                # This is tricky, so let's skip this case for now
                j += 1
                continue

            break

        # If we didn't find any conditions, output the original lines
        if not conditions:
            out.append(lines[i])
            i += 1
            continue

        # Now look for the sentinel check: $L2x8F=<const>; $L2x8G=<val>; $L2x8H=$L2xOiRyN==<val>; if($L2x8H){
        # Skip any lines between conditions and check
        k = j
        while k < n:
            l = lines[k].strip()
            # Find the check pattern: $L2x8F=<const>; $L2x8G=<val>; $L2x8H=$L2xOiRyN==<val>; if($L2x8H){
            m5 = re.match(r'^\$L2x8F\s*=\s*(\d+);$', l)
            if m5:
                if k + 1 < n:
                    nl1 = lines[k + 1].strip()
                    m6 = re.match(r'^\$L2x8G\s*=\s*(\d+);$', nl1)
                    if m6:
                        check_val = m6.group(1)
                        if k + 2 < n:
                            nl2 = lines[k + 2].strip()
                            m7 = re.match(r'^\$L2x8H\s*=\s*\$' + sentinel_name + r'\s*==\s*(\d+);$', nl2)
                            if m7 and m7.group(1) == check_val:
                                if k + 3 < n:
                                    nl3 = lines[k + 3].strip()
                                    m8 = re.match(r'^if\(\$L2x8H\)(.*)$', nl3)
                                    if m8:
                                        # Found the check!
                                        # If the check value is in our conditions, simplify
                                        if check_val in conditions:
                                            cond = conditions[check_val]
                                            rest = m8.group(1)
                                            # Replace the sentinel block with direct if
                                            if rest == '{':
                                                # Replace: sentinel init + conditions + check + if{$ → if(cond){
                                                out.append(f'if({cond}){{')
                                                k += 4
                                                # Skip the rest of the sentinel block
                                                break
                                            elif rest.startswith('{'):
                                                out.append(f'if({cond}){rest}')
                                                k += 4
                                                break
                                            elif rest.startswith('goto'):
                                                out.append(f'if({cond}){rest}')
                                                k += 4
                                                break
                                            elif rest == '':
                                                # Check if next line is {
                                                if k + 4 < n and lines[k + 4].strip() == '{':
                                                    out.append(f'if({cond}){{')
                                                    k += 5
                                                    break
                                                out.append(f'if({cond}){{')
                                                k += 4
                                                break
                        # Check for single-line if: if($L2x8H){code};
                        if m7:
                            pass  # handled above
            # Check for if($L2x8H){ on one line
            m9 = re.match(r'^if\(\$L2x8H\)(.*)$', l)
            if m9 and conditions:
                rest = m9.group(1)
                # Look backwards for the check pattern
                # This is complex, skip for now
                pass
            k += 1

        # If we didn't find a match, output original lines
        if k == j:
            out.append(lines[i])
            i += 1
        else:
            i = k

    return out


def remove_dead_sentinels(lines):
    """Remove remaining dead sentinel variable assignments."""
    out = []
    sentinel_vars = set()
    # First pass: collect all sentinel variable names
    for line in lines:
        for m in re.finditer(r'\$L2x(?:OiRy|8|9|A[BCD]?)\d*\b', line):
            sentinel_vars.add(m.group())
    # Second pass: find which sentinel vars are read (used in RHS)
    read_vars = set()
    for line in lines:
        for m in re.finditer(r'\$L2x(?:OiRy|8|9|A[BCD]?)\d*\b', line):
            # Check if it's on RHS of assignment or in condition
            stripped = line.strip()
            if not stripped.startswith('$' + m.group()[1:] + '='):
                read_vars.add(m.group())
    # Remove sentinel variables that are never read
    dead_vars = sentinel_vars - read_vars
    for line in lines:
        # Remove lines that are just assignments to dead sentinel vars
        stripped = line.strip()
        is_dead = False
        for var in dead_vars:
            if stripped.startswith(var + '='):
                is_dead = True
                break
        if not is_dead:
            out.append(line)
    return out


def _extract_arr_val(line, var_name):
    """Extract value from $var[]=VALUE; stripping & reference prefix."""
    stripped = line.strip()
    prefix = f'${var_name}[]='
    if not stripped.startswith(prefix):
        return None
    val = stripped[len(prefix):].strip()
    if val.endswith(';'):
        val = val[:-1].strip()
    if val.startswith('&'):
        val = val[1:].strip()
    return val


def convert_cufa(lines):
    """Convert call_user_func_array to direct calls."""
    out = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        stripped = line.strip()
        indent = line[:len(line) - len(line.lstrip())]

        # Pattern: $result=call_user_func_array($callable_arr,$args_arr);
        m = re.match(r'^\$(\w+)=call_user_func_array\(\$(\w+),\$(\w+)\);?$', stripped)
        if m:
            result_var = m.group(1)
            callable_var = m.group(2)
            args_var = m.group(3)

            # Look backwards through out for array construction lines
            args = []
            callable_parts = []
            j = len(out) - 1
            while j >= 0:
                pl = out[j]
                ps = pl.strip()
                if ps.startswith(f'${args_var}[]='):
                    val = _extract_arr_val(pl, args_var)
                    if val is not None:
                        args.insert(0, val)
                    j -= 1
                elif ps.startswith(f'${callable_var}[]='):
                    val = _extract_arr_val(pl, callable_var)
                    if val is not None:
                        callable_parts.insert(0, val)
                    j -= 1
                else:
                    break

            # Remove consumed array lines from out
            out = out[:j + 1]

            if len(callable_parts) == 2:
                obj = callable_parts[0]
                method = callable_parts[1].strip('"\''  )
                if args:
                    call = f'${result_var}={obj}->{method}({", ".join(args)});'
                else:
                    call = f'${result_var}={obj}->{method}();'
                out.append(indent + call)
            elif len(callable_parts) == 1:
                func = callable_parts[0].strip('"\''  )
                if args:
                    call = f'${result_var}={func}({", ".join(args)});'
                else:
                    call = f'${result_var}={func}();'
                out.append(indent + call)
            else:
                out.append(lines[i])

            i += 1
            while i < n and re.match(r'^unset\(.*\);?$', lines[i].strip()):
                i += 1
            if i < n:
                s = lines[i].strip()
                if s.startswith(f'${result_var}=') and s.endswith(';') and s != stripped:
                    i += 1
            continue

        # Simpler pattern: $result=call_user_func_array("func_name",$arr);
        m2 = re.match(r'^\$(\w+)=call_user_func_array\("([^"]+)",\$(\w+)\);?$', stripped)
        if m2:
            result_var = m2.group(1)
            func_name = m2.group(2)
            args_var = m2.group(3)

            args = []
            j = len(out) - 1
            while j >= 0:
                ps = out[j].strip()
                if ps.startswith(f'${args_var}[]='):
                    val = _extract_arr_val(out[j], args_var)
                    if val is not None:
                        args.insert(0, val)
                    j -= 1
                else:
                    break
            out = out[:j + 1]

            if args:
                call = f'${result_var}={func_name}({", ".join(args)});'
            else:
                call = f'${result_var}={func_name}();'
            out.append(indent + call)
            i += 1
            while i < n and re.match(r'^unset\(.*\);?$', lines[i].strip()):
                i += 1
            continue

        out.append(lines[i])
        i += 1
    return out


def fix_empty_if_not(lines):
    """Fix if(!COND){}else{code} → if(COND){code}"""
    out = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        stripped = line.strip()
        # Pattern: if(!(EXPR)){   on one line, followed by }else{ on next
        m = re.match(r'^if\(!\((.*)\)\)\{$', stripped)
        if m:
            if i + 1 < n and lines[i + 1].strip() == '}else{':
                # Replace: if(!(cond)){}else{ → if(cond){
                out.append(' ' * (len(line) - len(line.lstrip())) + f'if({m.group(1)})' + '{')
                i += 2
                continue
        # Pattern: if(!(\$COND)){}else{  (variable case)
        m2 = re.match(r'^if\(!\$(\w+)\)\{\s*\}\s*else\{', stripped)
        if m2:
            out.append(' ' * (len(line) - len(line.lstrip())) + f'if(${m2.group(1)})' + '{')
            i += 1
            continue
        # Pattern: if(!(\$COND)){}else{code}  (multi-line)
        m3 = re.match(r'^if\(!\$(\w+)\)\{$', stripped)
        if m3:
            if i + 1 < n and lines[i + 1].strip() == '}' and i + 2 < n and lines[i + 2].strip().startswith('}else{'):
                out.append(' ' * (len(line) - len(line.lstrip())) + f'if(${m3.group(1)})' + '{')
                i += 3
                continue
        out.append(lines[i])
        i += 1
    return out


def inline_trivial_intermediates(lines):
    """Inline $L2x* variables that are assigned and immediately used once."""
    # Find variables that are assigned once and used immediately
    out = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        stripped = line.strip()

        # Pattern: $L2xeF8F=json_encode($arr, FLAGS); exit($L2xeF8F);
        m = re.match(r'^\$L2x\w+=(.+?);\s*exit\(\$L2x\w+\);$', stripped)
        if m:
            expr = m.group(1)
            out.append(' ' * (len(line) - len(line.lstrip())) + f'exit({expr});')
            i += 1
            continue

        # Pattern: $L2xeF8F=json_encode($arr, FLAGS);\n$L2xeF8F;  → $L2xeF8F is used as exit() arg
        m2 = re.match(r'^\$L2x\w+=(.+?);$', stripped)
        if m2:
            expr = m2.group(1)
            # Check next line: $L2x* is used as exit/die/return arg
            if i + 1 < n:
                nl = lines[i + 1].strip()
                m3 = re.match(r'^(exit|die|return)\s*\(\$L2x\w+\);$', nl)
                if m3:
                    keyword = m3.group(1)
                    out.append(' ' * (len(line) - len(line.lstrip())) + f'{keyword}({expr});')
                    i += 2
                    continue

        out.append(lines[i])
        i += 1
    return out


def format_code(text):
    """Apply basic formatting: indentation, spacing."""
    lines = text.split('\n')
    out = []
    indent = 0
    for line in lines:
        stripped = line.strip()
        if not stripped:
            out.append('')
            continue

        # Decrease indent for closing braces
        if stripped.startswith('}'):
            indent = max(0, indent - 1)

        # Add indentation
        if indent > 0:
            out.append('    ' * indent + stripped)
        else:
            out.append(stripped)

        # Increase indent for opening braces
        if stripped.endswith('{') or stripped.endswith('{;'):
            indent += 1

    return '\n'.join(out)


def main():
    import sys, os
    pattern = sys.argv[1] if len(sys.argv) > 1 else '/tmp/phpdec/clean2/*.deobf.php'
    files = sorted(glob.glob(pattern))
    for path in files:
        cleanup_file(path)
        print(f"  OK: {os.path.basename(path)}")
    print(f"Phase 2 cleanup done: {len(files)} files")

if __name__ == '__main__':
    main()