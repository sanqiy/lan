#!/usr/bin/env python3
"""PHP 二次混淆(控制流平坦化)还原器 — 核心引擎
处理对象: 已剥离加密壳的 $L2x* 变量 + goto 矩阵 + 数值哨兵 混淆代码。

流程(迭代直至稳定):
  1. 常数表收集  : $L2xBuEtN=array();...[]=k  -> arrs
  2. 数值/布尔传播: 常量赋值/$var/$var+/-* 常量传播
  3. 判定折叠    : if(CONST) goto T; goto F;  -> goto (真分支)
  4. goto 化简   : goto X;X: 相邻 消除
  5. 死代码删除  : 可达性分析, 删除不可达普通语句
"""
import re, sys, os

ST = re.compile(r"^\s*([A-Za-z_\x80-\xff][\w\x80-\xff]*)\s*:\s*$")
GO = re.compile(r"^\s*goto\s+([A-Za-z_]\w*)\s*$")
IG = re.compile(r"^\s*if\s*\(\s*(.*?)\s*\)\s*goto\s+([A-Za-z_]\w*)\s*$")
ARR_INIT = re.compile(r"^\s*\$\w+\s*=\s*array\(\)\s*$")
ARR_ITEM = re.compile(r"^\s*\$(\w+)\[\s*\]\s*=\s*(-?\d+)\s*$")
ARR_IDX  = re.compile(r"\$(\w+)\[(\d+)\]")
ASSIGN   = re.compile(r"^\s*\$(\w+)\s*=\s*(.*?)\s*$")
NUM      = re.compile(r"^\d+$")
WORD     = re.compile(r"^\$[\w]+$")

def split_stmts(code):
    """按 ; 分割语句，感知 ' " ` 三种引号与转义."""
    stmts=[]; cur=''; i=0; n=len(code); q=None
    while i<n:
        c=code[i]
        if q:
            cur+=c
            if c=='\\' and i+1<n:
                cur+=code[i+1]; i+=2; continue
            if c==q: q=None
            i+=1; continue
        if c in "'\"`":
            q=c; cur+=c; i+=1; continue
        if c==';':
            stmts.append(cur); cur=''; i+=1; continue
        cur+=c; i+=1
    if cur.strip(): stmts.append(cur)
    return stmts

class Tokenizer:
    """把语句流解析成带类型的 token 列表(合并 if-goto;goto 对)."""
    def __init__(self, stmts):
        self.toks=[]   # (kind, payload)
        # kind: 'stmt' text | 'label' name | 'jump' (label) | 'cjump' (cond, target, falltarget)
        for s in stmts:
            # 剥离行首 label 前缀, 例如 "L2xeWjgx2:$L2xOiRy1=..." 或
            # "L2xldMhx2:L2xx1:echo ..." (可能连续多个 label)
            head = s
            while True:
                m = re.match(r'^\s*([A-Za-z_]\w*)\s*:', head)
                if not m:
                    break
                self.toks.append(('label', m.group(1)))
                head = head[m.end():]
                if head.strip() == '':
                    break
            s = head
            if s.strip() == '': continue
            m=ST.match(s)
            if m:
                self.toks.append(('label', m.group(1))); continue
            m=GO.match(s)
            if m:
                self.toks.append(('jump', m.group(1))); continue
            m=IG.match(s)
            if m:
                self.toks.append(('cjump', (m.group(1), m.group(2)))); continue
            self.toks.append(('stmt', s))
        # 把 cjump 后跟 jump 合并成 (cond, T, F)
        out=[]
        i=0
        while i<len(self.toks):
            if self.toks[i][0]=='cjump':
                cond, tgt = self.toks[i][1]
                ft = None
                if i+1<len(self.toks) and self.toks[i+1][0]=='jump':
                    ft = self.toks[i+1][1]
                    out.append(('cjump2',(cond,tgt,ft)))
                    i+=2; continue
                out.append(self.toks[i]); i+=1; continue
            out.append(self.toks[i]); i+=1
        self.toks=out

    def labelmap(self):
        return {name:i for i,(k,name) in enumerate(self.toks) if k=='label'}

def eval_num(expr, vals):
    """返回 (ok, value). 支持 数字 / $var / + - * 混合, 以及 == 判定."""
    expr=expr.strip()
    if expr=='': return (False,None)
    # 含引号或反引号即字符串字面量, 不做数值求值(避免引号内数字被误析出)
    if any(c in expr for c in "'\"`"):
        return (False,None)
    if expr in ('true','TRUE'): return (True,True)
    if expr in ('false','FALSE'): return (True,False)
    m=re.fullmatch(r'\d+', expr)
    if m: return (True,int(expr))
    m=re.fullmatch(r'\$(\w+)', expr)
    if m and m.group(1) in vals:
        return (True, vals[m.group(1)])
    # == 判定 (两侧均可为常量/已知变量)
    idx=expr.find('==')
    if idx>=0:
        a=expr[:idx].strip().lstrip('(').rstrip(')')
        b=expr[idx+2:].strip().lstrip('(').rstrip(')')
        okA,valA=eval_num(a, vals) if a else (False,None)
        okB,valB=eval_num(b, vals) if b else (False,None)
        if okA and okB and isinstance(valA,(int,bool)) and isinstance(valB,(int,bool)):
            return (True, bool(valA==valB))
        return (False,None)
    # 算术
    try:
        # token 化
        toks=re.findall(r'\$[\w]+|-?\d+|[+\-*]', expr)
        if not toks: return (False,None)
        # 替换变量
        parts=[]
        for t in toks:
            if t.startswith('$'):
                if t[1:] in vals and isinstance(vals[t[1:]],(int,bool)):
                    parts.append(str(int(vals[t[1:]])))
                else:
                    return (False,None)
            else:
                parts.append(t)
        s=''.join(parts)
        if re.fullmatch(r'[0-9+\-*\s]*', s) and '**' not in s:
            v=eval(s, {'__builtins__':{}}, {})
            if isinstance(v,int): return (True,v)
            return (False,None)
    except Exception:
        return (False,None)
    return (False,None)

def join_states(a, b):
    """两分支状态的 meet: 仅在两侧值一致时保留, 否则视为 unknown(删除)."""
    out={}
    for k in set(a) | set(b):
        if k in a and k in b and a[k]==b[k]:
            out[k]=a[k]
    return out

def fold_expr_text(ex, st):
    """文本级常量折叠: 把已知 int 常量变量替换进表达式, 引号感知.
    返回 (new_expr, full_const). bool 值不替换(避免 == 松散比较改语义)."""
    out=[]; i=0; n=len(ex); q=None
    while i<n:
        c=ex[i]
        if q:
            out.append(c)
            if c=='\\' and i+1<n:
                out.append(ex[i+1]); i+=2; continue
            if c==q: q=None
            i+=1; continue
        if c in '\'"`':
            q=c; out.append(c); i+=1; continue
        if c=='$' and i+1<n and (ex[i+1].isalpha() or ex[i+1]=='_'):
            m=re.match(r'\$[A-Za-z_]\w*', ex[i:])
            if m:
                vn=m.group(0)[1:]
                if vn in st and isinstance(st[vn], int):
                    out.append(str(st[vn]))
                    i+=m.end(); continue
                out.append(m.group(0)); i+=m.end(); continue
        out.append(c); i+=1
    new=''.join(out)
    ok,v=eval_num(new, {})
    if ok and isinstance(v, int):
        return str(v), True
    return new, False

def dataflow_fold(toks, arrs):
    """基于 CFG 数据流的一轮折叠. 返回 (newtoks, changed).
    overweight 顺序单路径传播会把合流处的分支相关判定错误折叠,
    因此这里: 先静态构造含全部边的基本块图, worklist 求各块入口
    常量状态(meet 语义: 分支不一致即 unknown), 再据此折叠 cjump."""
    # 1) 数组内联
    newtoks=[]; changed=False
    for k,pay in toks:
        if k=='stmt':
            np=pay
            for m in ARR_IDX.finditer(pay):
                an=m.group(1); ad=int(m.group(2))
                if an in arrs and ad < len(arrs[an]):
                    np=np.replace(m.group(0), str(arrs[an][ad])); changed=True
            newtoks.append((k,np))
        else:
            newtoks.append((k,pay))
    toks=newtoks
    # 2) 基本块
    starts=[0]+[i for i,(k,_) in enumerate(toks) if k=='label']
    starts=sorted(set(starts))
    blocks=[toks[starts[b]:(starts[b+1] if b+1<len(starts) else len(toks))]
            for b in range(len(starts))]
    label_bid={}
    for b,seg in enumerate(blocks):
        for k,p in seg:
            if k=='label':
                label_bid[p]=b
                break
        else:
            continue
    # 3) 静态后继(不折叠边): 存在任何跳转则以目标为后继; 否则顺落至下一块
    succ=[[] for _ in blocks]
    for b,seg in enumerate(blocks):
        flow=False
        for k,p in seg:
            if k=='jump':
                flow=True
                if p in label_bid: succ[b].append(label_bid[p])
            elif k=='cjump2':
                flow=True
                _,T,F=p
                if T in label_bid: succ[b].append(label_bid[T])
                if F in label_bid: succ[b].append(label_bid[F])
            elif k=='cjump':
                flow=True
                _,T=p
                if T in label_bid: succ[b].append(label_bid[T])
        if not flow and b+1<len(blocks):
            succ[b].append(b+1)
    # 4) 数据流
    entry=[None]*len(blocks)   # None = 未访问(unknown 一切)
    entry[0]={}
    work=[0]
    while work:
        b=work.pop()
        st=dict(entry[b])
        seg=blocks[b]
        for k,pay in seg:
            if k=='stmt':
                m=ASSIGN.match(pay)
                if m:
                    vn=m.group(1); ex=m.group(2)
                    ok,val=eval_num(ex,st)
                    if ok and isinstance(val,(int,bool)):
                        st[vn]=val
                    else:
                        st.pop(vn,None)
                elif pay.startswith('echo'):
                    pass                      # 无副作用
                elif pay.startswith('unset('):
                    mm=re.search(r'unset\(\s*\$(\w+)', pay)
                    if mm: st.pop(mm.group(1),None)
                elif '(' in pay:
                    st.clear()                # 保守: 未知副作用
            # label / jump / cjump 不改状态
        for s in set(succ[b]):
            if entry[s] is None:
                entry[s]=dict(st); work.append(s)
            else:
                merged=join_states(entry[s], st)
                if merged!=entry[s]:
                    entry[s]=merged; work.append(s)
    # 5) 基于入口状态折叠 cjump + 文本级常量重写
    out=[]
    for b,seg in enumerate(blocks):
        st=dict(entry[b]) if entry[b] else {}
        for j,(k,pay) in enumerate(seg):
            if k=='stmt':
                m=ASSIGN.match(pay)
                if m:
                    vn=m.group(1); ex=m.group(2)
                    ok,val=eval_num(ex,st)
                    if ok and isinstance(val,(int,bool)):
                        st[vn]=val
                    else:
                        st.pop(vn,None)
                    # 文本重写: 已知 int 变量替换进表达式
                    if vn.startswith('L2x'):
                        ne,full=fold_expr_text(ex, st)
                        if ne!=pay.split('=',1)[1].strip():
                            np=f'${vn}={ne}'
                            if np!=pay:
                                changed=True
                                pay=np
                elif pay.startswith('echo'):
                    pass
                elif pay.startswith('unset('):
                    mm=re.search(r'unset\(\s*\$(\w+)', pay)
                    if mm: st.pop(mm.group(1),None)
                elif '(' in pay:
                    st.clear()                # 保守: 未知副作用
                out.append((k,pay))
            elif k=='cjump2':
                cond,T,F=pay
                ok,val=eval_num(cond,st)
                if ok and isinstance(val,bool):
                    target=T if val else F
                    changed=True
                    out.append(('jump',target))
                else:
                    out.append((k,pay))
            else:
                out.append((k,pay))
    return out, changed

def fold_tokens(toks, arrs):
    """兼容旧接口: 直接转 dataflow_fold."""
    return dataflow_fold(toks, arrs)

def reachable_filter(toks):
    """可达性过滤: 保留可达的语句, 保留所有 label 定义, 删除不可达普通语句.
    含结构花括号的 stmt (try/catch/finally/if/else 收尾等) 不删除, 避免破坏语法结构."""
    lmap={name:i for i,(k,name) in enumerate(toks) if k=='label'}
    alive=set(); stack=[0]
    while stack:
        idx=stack.pop()
        if idx in alive or idx>=len(toks) or idx<0: continue
        while idx<len(toks):
            alive.add(idx)
            k,pay=toks[idx]
            if k=='jump':
                t=lmap.get(pay)
                if t is not None: stack.append(t)
                break
            if k=='cjump2':
                _,T,F=pay
                if T in lmap: stack.append(lmap[T])
                if F in lmap: stack.append(lmap[F])
                break
            if k=='cjump':
                _,T=pay
                if T in lmap: stack.append(lmap[T])
                # 无 fallthrough 信息,双分支保守
                break
            idx+=1
    out=[]
    for i,(k,pay) in enumerate(toks):
        if k!='stmt':
            out.append((k,pay)); continue
        if '{' in pay or '}' in pay:
            out.append((k,pay)); continue
        if i in alive or k=='label':
            out.append((k,pay))
    return out

def chaingoto_elim(toks):
    """goto X; X: 相邻消除 (仅当 X 是下一个 label)."""
    lmap={name:i for i,(k,name) in enumerate(toks) if k=='label'}
    changed=False
    out=[]
    i=0
    while i<len(toks):
        k,pay=toks[i]
        if k=='jump' and i+1<len(toks) and toks[i+1][0]=='label' and toks[i+1][1]==pay:
            changed=True
            out.append(toks[i+1]); i+=2; continue
        out.append((k,pay)); i+=1
    return out, changed

def count_jump_refs(toks):
    cnt={}
    for k,p in toks:
        if k=='jump': cnt[p]=cnt.get(p,0)+1
        elif k=='cjump2':
            _,T,F=p; cnt[T]=cnt.get(T,0)+1
            if F: cnt[F]=cnt.get(F,0)+1
        elif k=='cjump':
            _,T=p; cnt[T]=cnt.get(T,0)+1
        elif k=='stmt' and isinstance(p,str):
            # stmt 内嵌 goto (如 '}goto L2xx13') 也算引用
            for mm in re.finditer(r'\bgoto\s+([A-Za-z_]\w*)\s*;?\s*$', p):
                cnt[mm.group(1)]=cnt.get(mm.group(1),0)+1
    return cnt

def foldgoto_chains(toks):
    """折叠 goto 转发链: label X: goto Y 且 X 无其他入边 → 所有 goto X 改 goto Y, 删 X。迭代到不动点."""
    toks=list(toks)
    while True:
        seq=toks
        lb={}; did=False; removed=False
        n=len(seq)
        for i,(k,p) in enumerate(seq):
            if k=='label':
                j=i+1
                while j<n and seq[j][0]=='label': j+=1
                if j<n and seq[j][0]=='jump':
                    lb[p]=seq[j][1]
        def resolve(l, path=None):
            if l not in lb: return l, True
            if path is None: path=set()
            if l in path: return l, False    # 环: 保守保留
            path.add(l)
            return resolve(lb[l], path)
        refs=count_jump_refs(seq)
        new=[]
        for k,p in seq:
            if k=='jump':
                r,ok=resolve(p)
                if ok and r!=p: did=True
                new.append(('jump',r) if ok else (k,p))
            elif k=='cjump2':
                c,T,F=p
                rT,okT=resolve(T); rF,okF=resolve(F)
                if okT and rT!=T: did=True; T=rT
                if F and okF and rF!=F: did=True; F=rF
                new.append(('cjump2',(c,T,F)))
            else:
                new.append((k,p))
        # 删除无人引用的纯转发 label 段 (label X: jump Y)
        seq2=[]; i=0; n2=len(new)
        refs2=count_jump_refs(new)
        while i<n2:
            k,p=new[i]
            if k=='label' and refs2.get(p,0)==0:
                j=i+1
                while j<n2 and new[j][0]=='label': j+=1
                if j<n2 and new[j][0]=='jump':
                    removed=True; i=j+1; continue
            seq2.append(new[i]); i+=1
        if not did and not removed: break
        toks=seq2
    return toks

def deflat(toks, depth=0):
    """递归展开平坦化三元组 → if/else 块. 返回 (out, fully_clean)."""
    seq=list(toks); n=len(seq); i=0; out=[]
    refs=count_jump_refs(seq)
    while i<n:
        k,p=seq[i]
        if k=='cjump2':
            cond,T,F=p
            if i+1<n and seq[i+1][0]=='label' and seq[i+1][1]==T:
                j=i+2; body=[]
                while j<n and seq[j][0]!='jump':
                    body.append(seq[j]); j+=1
                if j<n and seq[j][0]=='jump':
                    M=seq[j][1]; k2=j+1
                    if k2<n and seq[k2][0]=='label' and seq[k2][1]==F:
                        k3=k2+1; fbody=[]
                        if k3<n and seq[k3][0]=='label' and seq[k3][1]==M:
                            if refs.get(T,0)==1 and refs.get(M,0)==1:
                                b, cb = deflat(body, depth+1)
                                if cb:
                                    out.append(('stmt','if('+cond+'){'))
                                    out.extend(b); out.append(('stmt','}'))
                                    i=k3+1; continue
                        else:
                            kb=k3
                            while kb<n:
                                if seq[kb][0]=='jump' and seq[kb][1]==M:
                                    kb+=1
                                    if kb<n and seq[kb][0]=='label' and seq[kb][1]==M: break
                                    else: kb=-1; break
                                if seq[kb][0]=='label' and seq[kb][1]==M: break
                                fbody.append(seq[kb]); kb+=1
                            if kb>=0 and kb<n and seq[kb][0]=='label' and seq[kb][1]==M:
                                if refs.get(T,0)==1 and refs.get(M,0)==1:
                                    b, cb = deflat(body, depth+1)
                                    f, cf = deflat(fbody, depth+1)
                                    if cb and cf:
                                        out.append(('stmt','if('+cond+'){'))
                                        out.extend(b); out.append(('stmt','}else{'))
                                        out.extend(f); out.append(('stmt','}'))
                                        i=kb+1; continue
            out.append(seq[i]); i+=1; continue
        out.append(seq[i]); i+=1
    clean=all(k not in ('label','jump','cjump','cjump2') for k,_ in out)
    return out, clean

def _parse_cjump2(toks, i, seen):
    """递归下降解析 toks[i] 处的 cjump2, 完整消费 T body / F body / 合流点 M.
    嵌套 cjump2 (T/F body 内) 递归展开; 内层与外层可共享同一合流点 M(else-if 链).
    支持倒置结构: cjump2→jump F→label F→F body→label T→T body→M.
    seen: 已输出的 label 集合, 防止重复 label.
    返回 (ok, out, next_index, M_name): next_index 指向 M 消费点之后.
    """
    n=len(toks)
    if i>=n or toks[i][0]!='cjump2':
        return (False,None,None,None)
    cond,T,F=toks[i][1]
    # 0) T==F: 无操作 cjump2, 直接跳过
    if T == F:
        return (True, [], i + 1, T)
    # 1) 跳过 extraneous jumps 找到 T label
    ti=i+1
    while ti<n and toks[ti][0]=='jump':
        ti+=1
    if ti>=n or toks[ti][0]!='label':
        return (False,None,None,None)
    if toks[ti][1]!=T:
        # 倒置结构: cjump2→jump F→label F→F body→label T→T body→M
        if toks[ti][1]==F:
            T,F=F,T
            cond='!('+cond+')'
            inverted=True
        else:
            return (False,None,None,None)
    else:
        inverted=False
    # 2) 收集 T body: 递归消费内层 cjump2; 直到 jump(to M) 或 fall-through 到 F label
    M=None; tj=ti+1; body_t=[]; fallthru_F=False
    while tj<n:
        k,p=toks[tj]
        if k=='cjump2':
            ok,sub,ni,subM=_parse_cjump2(toks, tj, seen)
            if not ok:
                return (False,None,None,None)
            body_t.extend(sub); tj=ni; continue
        if k=='jump':
            M=p; tj+=1; break
        if k=='label':
            if p==F:
                fallthru_F=True; tj+=1; break
            if p not in seen:
                seen.add(p)
                body_t.append(('label',p))
            tj+=1; continue
        body_t.append(toks[tj]); tj+=1
    if M is None and not fallthru_F:
        return (False,None,None,None)
    # 2b) F == M: if without else (空 F body)
    if M is not None and M == F:
        body_t = forward_goto_flatten(body_t, seen)
        out = [('stmt', 'if(' + cond + '){')]
        out.extend(body_t)
        out.append(('stmt', '}'))
        fi = tj
        while fi < n and toks[fi][0] == 'jump':
            fi += 1
        if fi >= n or toks[fi][0] != 'label' or toks[fi][1] != M:
            return (False, None, None, None)
        if M not in seen:
            seen.add(M)
            out.append(('label', M))
        return (True, out, fi + 1, M)
    # 3) 定位 F label
    if not fallthru_F:
        fi=tj
        while fi<n and toks[fi][0]=='jump':
            fi+=1
        if fi>=n or toks[fi][0]!='label' or toks[fi][1]!=F:
            return (False,None,None,None)
        fj=fi+1
    else:
        fj=tj   # F label 已在 T body 收集中消费
    # 4) 收集 F body 直到 M label
    body_f=[]; consumed_merge=False
    while fj<n:
        k,p=toks[fj]
        if k=='cjump2':
            ok,sub,ni,subM=_parse_cjump2(toks, fj, seen)
            if not ok:
                return (False,None,None,None)
            body_f.extend(sub); fj=ni
            if subM is not None and subM==M:
                # 内层已消费共享合流点 M
                consumed_merge=True
                break
            continue
        if k=='jump':
            if p==M and not fallthru_F:
                fj+=1
                if fj<n and toks[fj][0]=='label' and toks[fj][1]==M:
                    fj+=1; break
                return (False,None,None,None)   # jump M 后未紧跟 label M
            if fallthru_F and M is None:
                M=p; fj+=1
                if fj<n and toks[fj][0]=='label' and toks[fj][1]==M:
                    fj+=1; break
                return (False,None,None,None)
            # jump 指向 F body 内部其他位置
            body_f.append(toks[fj]); fj+=1
            continue
        if k=='label':
            if M is not None and p==M:
                fj+=1; break
            if fallthru_F and M is None:
                M=p; fj+=1; break
            return (False,None,None,None)       # 其他 label, 放弃
        body_f.append(toks[fj]); fj+=1
    # 5) 若 F body 到达流末尾仍无 M, 该 cjump2 不应消耗标签(外层可能引用)
    if M is None:
        return (False,None,None,None)
    # 6) 再次展开 body 内的剩余 cjump2
    body_t=forward_goto_flatten(body_t, seen)
    body_f=forward_goto_flatten(body_f, seen)
    out=[]
    if T not in seen and T != M:
        seen.add(T); out.append(('label',T))
    if F not in seen and F != M:
        seen.add(F); out.append(('label',F))
    out.append(('stmt','if('+cond+'){'))
    out.extend(body_t)
    if body_f:
        out.append(('stmt','}else{'))
        out.extend(body_f)
    out.append(('stmt','}'))
    if M is not None and not consumed_merge and M not in seen:
        seen.add(M)
        out.append(('label',M))
    return (True, out, fj, M)

def forward_goto_flatten(toks, seen=None):
    """处理 struct_pass 残留的 forward goto 模式: else-if 链 / 嵌套 cjump2 / 合并点多引用.
    递归下降: 完整消费嵌套 cjump2 (含共享合流点), 输出 if/else 并保留合流点 label."""
    if seen is None:
        seen=set()
    out=[]; i=0; n=len(toks)
    while i<n:
        k,p=toks[i]
        if k!='cjump2':
            out.append(toks[i]); i+=1; continue
        local_seen=set(seen)
        ok,sub,ni,_=_parse_cjump2(toks, i, local_seen)
        if ok:
            seen.update(local_seen)
            out.extend(sub); i=ni; continue
        out.append(toks[i]); i+=1
    return out

def struct_pass(toks, rounds=40):
    """控制流结构化主 pass: 链折叠 + 三元组展开迭代到不动点. 返回 token 列表."""
    t=foldgoto_chains(toks)
    last=sum(1 for k,p in t if k in('label','jump','cjump','cjump2'))
    for _ in range(rounds):
        t,_=deflat(t)
        cur=sum(1 for k,p in t if k in('label','jump','cjump','cjump2'))
        if cur>=last:
            break
        last=cur
    return forward_goto_flatten(t)

def relay_elim(toks):
    """中转寄存器消除: $R=EXPR; … $DST=$R;  →  $DST=EXPR;
    在 token 序列上操作. 寄存器名以 L2x 开头. 保守: EXPR 无函数调用,
    R 在两次赋值间不被再引用/改值; 逐轮迭代到不动点."""
    def is_side_effect_free(expr):
        if '->' in expr or '::' in expr: return False
        if re.search(r'\b(?:new|eval|include|require|call_)\s*\(', expr): return False
        # 排除函数调用 (允许配对括号的数组访问处理)
        if re.search(r'\$[A-Za-z_]\w*\s*\(', expr): return False
        if re.search(r'\b[A-Za-z_]\w+\s*\(', expr): return False
        return True
    seq=list(toks)
    changed=True
    while changed:
        changed=False
        out=[]
        n=len(seq)
        for i,(k,p) in enumerate(seq):
            if k!='stmt':
                out.append(seq[i]); continue
            if '\n' in p:
                out.append(seq[i]); continue  # 跨行字符串: 不处理, 保守
            s=p.strip()
            m=re.match(r'\$(\w+)=(.*)', s)
            consumed=False
            if m and m.group(1).startswith('L2x'):
                reg=m.group(1); expr=m.group(2).strip().rstrip(';')
                if is_side_effect_free(expr):
                    # 向前找最近一次使用 $DST=$REG (允许夹 unset/无关语句, 只要 REG 不被重新赋值或被使用)
                    j=i+1
                    while j<n:
                        k2,p2=seq[j]
                        t2=p2.strip() if isinstance(p2,str) else ''
                        if k2=='label': j+=1; continue
                        if not t2: j+=1; continue
                        mm=re.match(r'\$([A-Za-z_]\w+)=(\$'+reg+r')\s*;?$', t2)
                        if mm:
                            dst=mm.group(1)
                            if not dst.startswith('L2x'):
                                # 替换 DST 行: dst=EXPR
                                seq[j]=('stmt', f'${dst}={expr}')
                                changed=True
                                consumed=True
                                break
                            j+=1; continue
                        # REG 被重新赋值或其他引用 → 停止
                        if re.search(r'\$'+reg+r'\b', t2) or 'unset(\$'+reg+r')' in t2:
                            break
                        j+=1
                    if consumed:
                        # 已消费, 跳过原赋值行
                        continue
            out.append(seq[i])
        seq=out
    return seq

def cufa_static(toks):
    """静态化 call_user_func_array("func", $arr) 为直接调用 func(...).
    仅处理函数名为字符串字面量、数组变量名以 L2xzA 开头的模式.
    收集前序连续的 $arr[]=EXPR 语句, 删除数组构建与 unset."""
    seq=list(toks)
    n=len(seq)
    delete=set()
    for i,(k,p) in enumerate(seq):
        if k!='stmt' or i in delete:
            continue
        s=p.strip()
        m=re.match(r'^\$(\w+)=call_user_func_array\("([^"]+)"\s*,\s*\$(\w+)\)$', s)
        if not m:
            continue
        res_var=m.group(1); func_name=m.group(2); arr_var=m.group(3)
        if not arr_var.startswith('L2xzA'):
            continue
        # 向后找 unset($ARR)
        unset_idx=None
        j=i+1
        while j<n:
            if seq[j][0]!='stmt':
                break
            t2=seq[j][1].strip()
            if t2==f'unset(${arr_var})':
                unset_idx=j
                break
            if re.search(r'\$'+arr_var+r'\b', t2):
                break
            j+=1
        # 向前收集连续的 $arr[]=EXPR
        args=[]
        j=i-1
        while j>=0:
            if seq[j][0]!='stmt' or j in delete:
                break
            t2=seq[j][1].strip()
            mm=re.match(r'^\$'+arr_var+r'\[\]=(.+)$', t2)
            if not mm:
                break
            args.insert(0, mm.group(1).strip().lstrip('&'))
            delete.add(j)
            j-=1
        if not args:
            continue
        args_str=', '.join(args)
        seq[i]=('stmt', f'${res_var}={func_name}({args_str})')
        if unset_idx is not None:
            delete.add(unset_idx)
    return [seq[i] for i in range(n) if i not in delete]

def totext(toks):
    lines=[]
    for k,pay in toks:
        if k=='label':
            lines.append(pay+':')
        elif k=='jump':
            lines.append('goto '+pay+';')
        elif k=='cjump2':
            cond,T,F=pay
            if F:
                lines.append('if('+cond+')goto '+T+';')
                lines.append('goto '+F+';')
            else:
                lines.append('if('+cond+')goto '+T+';')
        elif k=='cjump':
            lines.append('if('+pay[0]+')goto '+pay[1]+';')
        else:
            lines.append(pay+';')
    return '\n'.join(lines)

def split_functions(code):
    """把 PHP 代码按顶层 function 定义切分 (函数调用/匿名函数不误判).
    函数声明模式: 前界非[$\\w] + function + 空白 + 标识符 + 空白*( 
    花括号配平提取函数体."""
    parts=[]
    pos=0; n=len(code)
    FUNC=re.compile(r'(?<![$\w])\bfunction\s+([A-Za-z_\x80-\xff][\w\x80-\xff]*)\s*\(')
    while pos<n:
        m=FUNC.search(code,pos)
        if not m: break
        # 找到函数体起始 {
        k=code.find('{', m.end())
        if k<0 or k-m.start()>200:
            pos=m.end(); continue
        # 从 { 配平到闭合 }
        depth=1; k+=1
        while k<n:
            ch=code[k]
            if ch=='\\' and k+1<n: k+=2; continue
            if ch=='\'' or ch=='"':
                q2=ch; k+=1
                while k<n and code[k]!=q2:
                    k+=1
                k+=1; continue
            if ch=='{': depth+=1
            elif ch=='}':
                depth-=1
                if depth==0: break
            k+=1
        end=k
        parts.append(('func', m.group(1), code[m.start():end+1]))
        pos=end+1
    return parts

def strip_comments(s):
    """剥离 PHP 注释(/* */ // #), 感知引号与转义."""
    out=[]; i=0; n=len(s); q=None
    while i<n:
        c=s[i]
        if q:
            out.append(c)
            if c=='\\' and i+1<n:
                out.append(s[i+1]); i+=2; continue
            if c==q: q=None
            i+=1; continue
        if c in "'\"":
            q=c; out.append(c); i+=1; continue
        # 注释
        if c=='/' and i+1<n and s[i+1]=='/':
            while i<n and s[i] not in '\r\n': i+=1
            continue
        if c=='/' and i+1<n and s[i+1]=='*':
            i+=2
            while i+1<n and not (s[i]=='*' and s[i+1]=='/'): i+=1
            i+=2; continue
        if c=='#' and (i==0 or s[i-1] in '\r\n'):
            while i<n and s[i] not in '\r\n': i+=1
            continue
        out.append(c); i+=1
    return ''.join(out)

def while_loop_text(text):
    """文本级 while 循环恢复: 识别后向 goto 模式并转换为 while 循环.
    模式:
        L2xxN:
            ...condition computation...
            if(cond)goto L2xeWjgxN;
            goto L2xldMhxN;
        L2xeWjgxN:
            ...body...
            goto L2xxN;
        L2xldMhxN:
    → while(true) { ...condition... if(!cond)break; body: body }
    """
    lines=text.split('\n')
    # 找到所有后向 goto
    label_ln={}
    for i,ln in enumerate(lines):
        m=re.match(r'^([A-Za-z_]\w+):', ln.strip())
        if m:
            label_ln[m.group(1)]=i
    back_edges=[]
    for i,ln in enumerate(lines):
        m=re.search(r'^\s*goto\s+(L2xx\w+);', ln)
        if m and m.group(1) in label_ln and label_ln[m.group(1)]<i:
            back_edges.append((i, m.group(1), label_ln[m.group(1)]))
    if not back_edges:
        return text
    # 按行号降序处理(从后往前, 避免行号偏移)
    back_edges.sort(key=lambda x:-x[0])
    # 标记哪些行被删除
    modified=False
    for goto_ln, loop_label, header_ln in back_edges:
        # 找前向 if-goto 对: 在 header 之后最近的 if(cond)goto T; goto F; 模式
        # 从 header_ln+1 开始找
        # 提取 cond 和 T/F 标签
        cond_line=None
        T_label=None
        F_label=None
        goto_f_line=None
        for j in range(header_ln+1, min(header_ln+50, len(lines))):
            mm=re.match(r'^\s*if\((.+)\)goto\s+([A-Za-z_]\w+);', lines[j].strip())
            if mm and cond_line is None:
                cond_line=j
                T_label=mm.group(2)
                # 下一行应是 goto F;
                if j+1<len(lines):
                    mm2=re.match(r'^\s*goto\s+([A-Za-z_]\w+);', lines[j+1].strip())
                    if mm2:
                        F_label=mm2.group(1)
                        goto_f_line=j+1
            if cond_line is not None:
                break
        if cond_line is None or T_label is None or F_label is None:
            continue
        # 找到 T 标签行
        T_ln=None
        for j in range(cond_line+1, min(cond_line+50, len(lines))):
            if re.match(r'^'+re.escape(T_label)+':', lines[j].strip()):
                T_ln=j
                break
        if T_ln is None:
            continue
        # 确认 body 中的后向 goto 到 loop_label
        has_back=False
        for j in range(T_ln+1, goto_ln+1):
            if re.search(r'\bgoto\s+'+re.escape(loop_label)+';', lines[j]):
                has_back=True
                break
        if not has_back:
            continue
        # 执行变换:
        # 1. header 行: L2xxN: → while(true) {
        # 2. 保留 cond_line 之前的行(条件计算)
        # 3. cond_line: if(cond)goto T; → if(!cond)break;
        # 4. 删除 goto_f_line: goto F;
        # 5. 保留 T 标签
        # 6. 保留 body (含后向 goto 行)
        # 7. 在后向 goto 行后插入 }
        # 变换: 插入新文本, 标记要删除的行
        # 改为: 文本替换块
        # 提取 header 到 cond_line 之前的代码
        pre_lines=lines[header_ln+1:cond_line]
        # 取 cond 表达式
        mm=re.match(r'if\((.+)\)goto\s+'+re.escape(T_label)+';', lines[cond_line].strip())
        cond_expr=mm.group(1) if mm else ''
        # body 行: T_ln+1 .. goto_ln-1
        body_lines=lines[T_ln+1:goto_ln]
        # 重建
        new_block=[]
        new_block.append('while(true){')
        new_block.extend(pre_lines)
        new_block.append(f'if(!{cond_expr})break;')
        new_block.append(lines[T_ln].strip())
        new_block.extend(body_lines)
        new_block.append('}')
        before=lines[:header_ln+1]
        after=lines[goto_ln+1:]
        # 合并
        lines=before+new_block+after
        modified=True
        break  # 一次只处理一个循环(处理后重新扫描)
    if modified:
        return while_loop_text('\n'.join(lines))
    return '\n'.join(lines)

def deobfuscate_unit(unit):
    """处理单个函数体/全局片段."""
    unit=strip_comments(unit)
    # 剥离 PHP 标签(可能居中)与首尾空白
    unit=re.sub(r'<\?php', '', unit)
    unit=re.sub(r'\?>', '', unit)
    stmts=split_stmts(unit)
    toks=Tokenizer(stmts)
    # 收集数组表
    arrs={}
    for kk,pay in toks.toks:
        if kk=='stmt':
            m=ARR_INIT.match(pay)
            if m:
                name=re.match(r'\$\w+', pay.lstrip())
                assert name
                name=name.group(0)[1:]
                arrs.setdefault(name,[])
                continue
            m=ARR_ITEM.match(pay)
            if m and m.group(1) in arrs:
                arrs[m.group(1)].append(int(m.group(2)))
    # 先做折叠, 再看残余引用
    t, changed = fold_tokens(toks.toks, arrs)
    # 若存在未内联的 arr 数字索引引用则回滚保留数组语句
    tail_text=' '.join((x[1] if isinstance(x[1],str) else '') for x in t)
    # tail_text 需要剔除数组拷贝语句本身? 数组定义语句不含 [n], 不会误命中
    need_keep=[n for n in arrs if re.search(r'\$'+n+r'\[\d+\]', tail_text)]
    if need_keep:
        # 简单方式: 从头再来,不删除数组定义
        return toks.toks  # 原文保底
    # 删除数组表语句
    kept=[]
    for k,pay in t:
        if k=='stmt':
            m=ARR_INIT.match(pay)
            if m: continue
            m=ARR_ITEM.match(pay)
            if m and m.group(1) in arrs: continue
        kept.append((k,pay))
    t=kept

    for _ in range(40):
        t, c1 = fold_tokens(t, {})
        t2 = reachable_filter(t)
        t3, c2 = chaingoto_elim(t2)
        if not (c1 or c2) and t3==t:
            break
        t=t3
    t=relay_elim(t)
    t=cufa_static(t)
    return struct_pass(t)

def wrap_php(res, orig):
    if orig.lstrip().startswith('<?php') and not res.lstrip().startswith('<?php'):
        return '<?php\n'+res
    return res

def deobfuscate(code):
    parts=split_functions(code)
    if not parts:
        txt=totext(deobfuscate_unit(code))
        txt=while_loop_text(txt)
        return wrap_php(txt, code)
    segs=[]; pos=0
    for (_kind,_name,body) in parts:
        idx=code.find(body, pos)
        if idx<0:
            continue
        if pos<idx: segs.append((False, code[pos:idx]))
        segs.append((True, body))
        pos=idx+len(body)
    segs.append((False, code[pos:]))
    out=[]
    for isf, txt in segs:
        if not isf:
            s=strip_comments(txt)
            s=re.sub(r'<\?php', '', s); s=re.sub(r'\?>', '', s)
            if 'goto' in s:
                inner=totext(deobfuscate_unit(txt))
                inner=while_loop_text(inner)
                out.append(inner)
            else:
                out.append(txt)
        else:
            body_c=strip_comments(txt)
            inner=body_c[body_c.index('{'):]
            # 去掉函数签名后的第一个 { 与末尾配平的 }
            inner_clean=inner[1:]
            idx=inner_clean.rfind('}')
            if idx>=0:
                inner_clean=inner_clean[:idx]
            tok=deobfuscate_unit(inner_clean)
            newinner='\n'+while_loop_text(totext(tok))+'\n'
            fname=body_c[:body_c.index('{')].strip()
            out.append(fname+' {'+newinner+'}')
    return wrap_php(''.join(out), code)

if __name__=='__main__':
    infile=sys.argv[1]; outfile=sys.argv[2]
    code=open(infile,encoding='utf-8',errors='replace').read()
    res=deobfuscate(code)
    open(outfile,'w',encoding='utf-8').write(res)
    print(f"{infile} -> {outfile}: {len(code)} -> {len(res)} bytes")