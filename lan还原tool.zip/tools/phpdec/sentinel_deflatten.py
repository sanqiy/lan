#!/usr/bin/env python3
"""哨兵分发链还原器 v5
把形如:
    $L2x8F=<D>; $L2x8G=<V>; $L2x8H=$S==<V>; if($L2x8H){; BODY }else{ ...(下一CASE) }
的链还原为:
    switch($L2xOiRyN){ case V:{BODY;break;} ... }
行级解析 + 花括号配平（跳过 PHP 字符串字面量 / 行级 token 化）。
关键规则：
  - 链分叉：顶层块中的 '}else{' 且后行紧跟 "同一 sent 的哨兵四连头"
  - 非链 else：body 内的普通 if-else，作为整体块跳过（不进链判定）
实现：对每行做 token 扫描（str? + { } + }else{），用一个 Stack 模拟。
遇到 }else{：弹一压一。当栈长度为1 且遇到 }else{，检查 next 是否哨兵头：
  - 是 => 链分叉，返回
  - 否 => 内部 else，继续（栈保持长度1，但记录深度计数器以识别其结束）
栈空 => 链尾 end。
"""
import re, sys

SENT_PAT = r'\$L2x8[A-Z0-9_]+\s*=\s*(?P<val>\d+);\s*'
HEAD_RE = re.compile(
    r'(?P<indent>[ \t]*)'
    r'\$L2x8[A-Z0-9_]+\s*=\s*\d+;\s*'
    + SENT_PAT +
    r'\$L2x8[A-Z0-9_]+\s*=\s*\$L2xOiRy(?P<sent>\w+)==(?P=val)\s*;\s*'
    r'if\(\$L2x8[A-Z0-9_]+\)\{;?\s*')


def tokens(line, instr_init=False, quote_init=''):
    """产出该行的结构 token: 'else块'(})/ '}' / '{'; 返回 (toks, instr, quote)
    instr: 行结束时是否仍在字符串中（处理跨行字符串）"""
    out = []
    i = 0
    n = len(line)
    instr = instr_init
    quote = quote_init
    while i < n:
        ch = line[i]
        if instr:
            if ch == '\\':
                i += 2
                continue
            if ch == quote:
                instr = False
            i += 1
            continue
        if ch == "'" or ch == '"':
            instr = True
            quote = ch
            i += 1
            continue
        if line.startswith('}else{', i):
            out.append('else')
            i += 6
            continue
        if ch == '{':
            out.append('{')
        elif ch == '}':
            out.append('}')
        i += 1
    return out, instr, quote


def find_matching(lines, i, sent=None, try_header=None):
    """从 i 行(if 下一行)扫描到链级边界。
    返回 (kind, idx)。idx 是边界行的行号。
    kind: 'else' | 'end' | 'none'
    链级 else 判定：'}else{' 后行的缩进与同 sent 四连且不含 goto/label 混入。
    """
    depth = 1
    j = i
    n = len(lines)
    instr = False
    quote = ''
    while j < n:
        toks, instr, quote = tokens(lines[j], instr, quote)
        for tok in toks:
            if tok == 'else':
                if depth == 1 and sent is not None and try_header is not None:
                    nxt = j + 1
                    gap_ok = True
                    for g in lines[nxt:nxt + 3]:
                        if re.match(r'\s*(goto\s+L2x|L2x\w+:)', g):
                            gap_ok = False
                            break
                    h2 = try_header(lines, nxt) if gap_ok else None
                    if h2 is not None and h2[0] == sent:
                        return 'else', j
                # 非链 else：弹一压一，深度净不变，继续扫描
                continue
            if tok == '{':
                depth += 1
            elif tok == '}':
                depth -= 1
                if depth == 0:
                    return 'end', j
                if depth < 0:
                    return 'none', j
        j += 1
    return 'none', j


def try_header(lines, i):
    chunk = '\n'.join(lines[i:i + 4])
    m = HEAD_RE.match(chunk)
    if m:
        return m.group('sent'), int(m.group('val')), m.group('indent'), i + 3
    return None


def process_file(text):
    lines = text.split('\n')
    n = len(lines)
    out = []
    i = 0
    while i < n:
        h = try_header(lines, i)
        if h is None:
            out.append(lines[i]); i += 1; continue
        sent, first_val, indent, first_ifline = h
        cases = []
        cur_val = first_val
        body_start = first_ifline + 1
        stop_consume = None
        chain_ok = True
        extra_trailers = []
        while True:
            kind, endi = find_matching(lines, body_start, sent, try_header)
            if kind == 'none':
                chain_ok = False
                break
            body = lines[body_start:endi]
            # 安全守门：body 内不得有 goto/label 残留（goto 语义无法纯 if/else 表达）
            for bl in body:
                if re.match(r'\s*(goto\s+L2x|L2x\w+:|\}?goto\s+)', bl):
                    chain_ok = False
                    break
            if not chain_ok:
                break
            if kind == 'end':
                cases.append((cur_val, body))
                m = len(cases)
                trailer_hits = []
                extra = 0
                t = endi + 1
                while t < n and extra < m - 1:
                    s = lines[t].strip()
                    if s == '}':
                        extra += 1
                        t += 1
                    else:
                        # 出现 label 或其它内容：链与 goto/其它结构混织，放弃整链
                        chain_ok = False
                        break
                if chain_ok:
                    # 链尾闭合 '}' 之后若同行还有代码(如 };function...{)，其内容需输出
                    tail_line = lines[endi]
                    m2 = re.match(r'^(?P<pre>[ \t]*)\}(?P<rest>.*)$', tail_line)
                    if m2 and m2.group('rest').strip():
                        rest = m2.group('rest')
                        tail_extra = m2.group('pre') + rest.lstrip(';').lstrip()
                        if '}' in rest:
                            chain_ok = False
                        else:
                            extra_trailers = [tail_extra]
                    else:
                        extra_trailers = []
                    stop_consume = t - 1
                break
            nxt = endi + 1
            h2 = try_header(lines, nxt)
            if h2 is None or h2[0] != sent:
                chain_ok = False
                break
            cases.append((cur_val, body))
            cur_val = h2[1]
            body_start = h2[3] + 1
            if len(cases) > 60:
                break
        if chain_ok and cases and stop_consume is not None:
            sw = []
            sw.append(indent + 'switch($L2xOiRy' + sent + '){')
            for val, body in cases:
                sw.append(indent + '    case ' + str(val) + ':{')
                sw.extend(body)
                sw.append(indent + '        break;')
                sw.append(indent + '    }')
            sw.append(indent + '}')
            out.extend(sw)
            out.extend(extra_trailers)
            i = stop_consume + 1
            continue
        out.append(lines[i]); i += 1
    return '\n'.join(out)


if __name__ == '__main__':
    path = sys.argv[1]
    out_path = sys.argv[2] if len(sys.argv) > 2 else path + '.sw.php'
    text = open(path).read()
    res = process_file(text)
    open(out_path, 'w').write(res)
    print(f"{path} -> {out_path}: {len(text)} -> {len(res)} bytes")
    try:
        import subprocess
        r = subprocess.run(['php', '-l', out_path], capture_output=True, text=True)
        print(r.stdout.strip() or r.stderr.strip())
    except FileNotFoundError:
        pass