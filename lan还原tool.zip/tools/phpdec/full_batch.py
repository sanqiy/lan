import subprocess, glob, sys, os
src_dir = sys.argv[1] if len(sys.argv) > 1 else 'decrypted'
out_dir = sys.argv[2] if len(sys.argv) > 2 else 'clean2'
engine = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'deobf_core.py')
os.makedirs(out_dir, exist_ok=True)
files = sorted(glob.glob(os.path.join(src_dir, '*.dec.php')))
ok=0; fail=[]; st=[]
for f in files:
    out=os.path.join(out_dir, os.path.basename(f).replace('.dec.php','.deobf.php'))
    r=subprocess.run(['python3',engine,f,out],capture_output=True,text=True)
    if r.returncode!=0:
        fail.append((f,'PY:'+r.stderr.strip()[:120])); continue
    l=subprocess.run(['php','-l',out],capture_output=True,text=True)
    if l.returncode!=0:
        fail.append((out,'PHP:'+l.stderr.strip()[:160]))
    else:
        ok+=1
        g=sum(1 for _ in open(out))
        st.append((g,out))
print(f"OK: {ok}/{len(files)}")
for f,e in fail: print("FAIL:",f,"\n ",e)
st.sort()
print("最小/最大输出行数:", st[0][0] if st else 0, st[-1][0] if st else 0)
