#!/usr/bin/env python3
"""变量语义重命名引擎。

基于赋值来源、数组键等上下文推断语义名。
对 L2x 变量做同文件内全局替换 (正则边界, 避免字面量误伤).
保留通用 temp 变量不赋予语义名(避免误命名).

使用方式:
    python3 rename_engine.py <输入.sw.php> [输出.sw.php]
"""

import re, sys, collections, os

# 语义权重规则: (predicate, name_fn, weight)
# predicate 是可调用, 接收赋值源字符串, 返回 bool
# name_fn 接收赋值源字符串, 返回语义名字符串或 None
RULES = [
    # --- HTTP 输入 ---
    (lambda s: s.startswith('$_POST['), lambda s: re.match(r"\$_POST\[['\"]([^'\"]+)['\"]\]", s).group(1), 5),
    (lambda s: s.startswith('$_GET['), lambda s: re.match(r"\$_GET\[['\"]([^'\"]+)['\"]\]", s).group(1), 5),
    (lambda s: s.startswith('$_SESSION['), lambda s: re.match(r"\$_SESSION\[['\"]([^'\"]+)['\"]\]", s).group(1), 4),
    (lambda s: s.startswith('$_SERVER['), lambda s: 'serverVal', 2),
    (lambda s: s.startswith('$_FILES['), lambda s: re.match(r"\$_FILES\[['\"]([^'\"]+)['\"]\]", s).group(1), 4),
    (lambda s: s.startswith('$_COOKIE['), lambda s: re.match(r"\$_COOKIE\[['\"]([^'\"]+)['\"]\]", s).group(1), 3),
    # --- DB 操作 ---
    (lambda s: '->query(' in s, lambda s: 'result', 5),
    (lambda s: '->fetch_assoc(' in s, lambda s: 'row', 5),
    (lambda s: '->fetch_array(' in s, lambda s: 'row', 5),
    (lambda s: '->fetch(' in s, lambda s: 'row', 4),
    (lambda s: '->prepare(' in s, lambda s: 'stmt', 5),
    (lambda s: '->execute(' in s, lambda s: 'execResult', 3),
    (lambda s: '->bind_param(' in s, lambda s: 'bindResult', 3),
    (lambda s: '->close(' in s, lambda s: 'closeResult', 2),
    (lambda s: s.startswith('new mysqli('), lambda s: 'conn', 5),
    (lambda s: s.startswith('new '), lambda s: re.match(r'new\s+(\w+)', s).group(1).lower(), 3),
    (lambda s: s.startswith('mysqli_query('), lambda s: 'queryResult', 4),
    (lambda s: s.startswith('mysqli_fetch_assoc('), lambda s: 'row', 5),
    (lambda s: s.startswith('mysqli_fetch_array('), lambda s: 'row', 5),
    (lambda s: s.startswith('mysqli_num_rows('), lambda s: 'numRows', 4),
    (lambda s: s.startswith('mysqli_real_escape_string('), lambda s: 'escaped', 3),
    (lambda s: s.startswith('mysqli_affected_rows('), lambda s: 'affectedRows', 3),
    (lambda s: s.startswith('mysqli_insert_id('), lambda s: 'insertId', 3),
    (lambda s: '->num_rows' in s, lambda s: 'numRows', 3),
    (lambda s: '->insert_id' in s, lambda s: 'insertId', 3),
    # --- 字符串操作 ---
    (lambda s: s.startswith('date('), lambda s: 'dateStr', 3),
    (lambda s: s.startswith('time('), lambda s: 'currentTime', 3),
    (lambda s: s.startswith('md5('), lambda s: 'hash', 3),
    (lambda s: s.startswith('sha1('), lambda s: 'hash', 3),
    (lambda s: s.startswith('strtotime('), lambda s: 'timestamp', 3),
    (lambda s: s.startswith('htmlspecialchars('), lambda s: 'escaped', 3),
    (lambda s: s.startswith('htmlentities('), lambda s: 'escaped', 3),
    (lambda s: s.startswith('addslashes('), lambda s: 'escaped', 2),
    (lambda s: s.startswith('stripslashes('), lambda s: 'unescaped', 2),
    (lambda s: s.startswith('explode('), lambda s: 'parts', 3),
    (lambda s: s.startswith('implode('), lambda s: 'joined', 3),
    (lambda s: s.startswith('join('), lambda s: 'joined', 3),
    (lambda s: s.startswith('str_replace('), lambda s: 'replaced', 3),
    (lambda s: s.startswith('str_ireplace('), lambda s: 'replaced', 2),
    (lambda s: s.startswith('strpos('), lambda s: 'pos', 3),
    (lambda s: s.startswith('stripos('), lambda s: 'pos', 2),
    (lambda s: s.startswith('strrpos('), lambda s: 'pos', 2),
    (lambda s: s.startswith('substr('), lambda s: 'substr', 2),
    (lambda s: s.startswith('trim('), lambda s: 'trimmed', 2),
    (lambda s: s.startswith('ltrim('), lambda s: 'trimmed', 2),
    (lambda s: s.startswith('rtrim('), lambda s: 'trimmed', 2),
    (lambda s: s.startswith('strtolower('), lambda s: 'lowered', 2),
    (lambda s: s.startswith('strtoupper('), lambda s: 'uppered', 2),
    (lambda s: s.startswith('ucfirst('), lambda s: 'ucfirst', 2),
    (lambda s: s.startswith('nl2br('), lambda s: 'nl2brResult', 2),
    (lambda s: s.startswith('strlen('), lambda s: 'length', 3),
    (lambda s: s.startswith('strstr('), lambda s: 'found', 2),
    (lambda s: s.startswith('stristr('), lambda s: 'found', 2),
    # --- JSON ---
    (lambda s: s.startswith('json_encode('), lambda s: 'jsonStr', 3),
    (lambda s: s.startswith('json_decode('), lambda s: 'jsonData', 3),
    # --- 类型检查与转换 ---
    (lambda s: s.startswith('is_array('), lambda s: 'isArray', 3),
    (lambda s: s.startswith('is_numeric('), lambda s: 'isNumeric', 2),
    (lambda s: s.startswith('is_string('), lambda s: 'isString', 2),
    (lambda s: s.startswith('is_null('), lambda s: 'isNull', 2),
    (lambda s: s.startswith('is_bool('), lambda s: 'isBool', 2),
    (lambda s: s.startswith('isset('), lambda s: 'isSet', 2),
    (lambda s: s.startswith('empty('), lambda s: 'isEmpty', 2),
    (lambda s: s.startswith('floatval('), lambda s: 'floatVal', 2),
    (lambda s: s.startswith('intval('), lambda s: 'intVal', 2),
    (lambda s: s.startswith('boolval('), lambda s: 'boolVal', 2),
    (lambda s: s.startswith('strval('), lambda s: 'strVal', 2),
    (lambda s: s.startswith('floor('), lambda s: 'floorVal', 2),
    (lambda s: s.startswith('ceil('), lambda s: 'ceilVal', 2),
    (lambda s: s.startswith('round('), lambda s: 'roundVal', 2),
    (lambda s: s.startswith('abs('), lambda s: 'absVal', 2),
    (lambda s: s.startswith('count('), lambda s: 'count', 3),
    (lambda s: s.startswith('sizeof('), lambda s: 'count', 3),
    # --- 文件与网络 ---
    (lambda s: s.startswith('file_exists('), lambda s: 'fileExists', 3),
    (lambda s: s.startswith('is_file('), lambda s: 'isFile', 3),
    (lambda s: s.startswith('is_dir('), lambda s: 'isDir', 3),
    (lambda s: s.startswith('file_get_contents('), lambda s: 'fileContent', 3),
    (lambda s: s.startswith('file_put_contents('), lambda s: 'writeResult', 3),
    (lambda s: s.startswith('fopen('), lambda s: 'fp', 3),
    (lambda s: s.startswith('fgets('), lambda s: 'line', 3),
    (lambda s: s.startswith('fwrite('), lambda s: 'writeResult', 2),
    (lambda s: s.startswith('fread('), lambda s: 'readResult', 2),
    (lambda s: s.startswith('fclose('), lambda s: 'closeResult', 2),
    (lambda s: s.startswith('feof('), lambda s: 'isEof', 2),
    (lambda s: s.startswith('filesize('), lambda s: 'fileSize', 2),
    (lambda s: s.startswith('move_uploaded_file('), lambda s: 'uploadResult', 3),
    (lambda s: s.startswith('copy('), lambda s: 'copyResult', 2),
    (lambda s: s.startswith('unlink('), lambda s: 'unlinkResult', 2),
    (lambda s: s.startswith('mkdir('), lambda s: 'mkdirResult', 2),
    (lambda s: s.startswith('rmdir('), lambda s: 'rmdirResult', 2),
    (lambda s: s.startswith('getenv('), lambda s: 'env', 3),
    # --- 正则与模式 ---
    (lambda s: s.startswith('preg_match('), lambda s: 'matchResult', 3),
    (lambda s: s.startswith('preg_match_all('), lambda s: 'matchResult', 3),
    (lambda s: s.startswith('preg_replace('), lambda s: 'replaced', 2),
    (lambda s: s.startswith('preg_split('), lambda s: 'parts', 2),
    # --- 网络/HTTP ---
    (lambda s: s.startswith('setcookie('), lambda s: 'cookieResult', 2),
    (lambda s: s.startswith('setrawcookie('), lambda s: 'cookieResult', 2),
    (lambda s: s.startswith('curl_init('), lambda s: 'curl', 4),
    (lambda s: s.startswith('curl_exec('), lambda s: 'curlResult', 3),
    (lambda s: s.startswith('curl_setopt('), lambda s: 'curlOptResult', 2),
    (lambda s: s.startswith('curl_error('), lambda s: 'curlError', 2),
    (lambda s: s.startswith('header('), lambda s: 'headerResult', 1),
    # --- 输出/缓冲 ---
    (lambda s: s.startswith('ob_get_clean('), lambda s: 'output', 3),
    (lambda s: s.startswith('ob_get_contents('), lambda s: 'output', 3),
    (lambda s: s.startswith('ob_start('), lambda s: 'obResult', 1),
    # --- 数组 ---
    (lambda s: s.startswith('array('), lambda s: 'arr', 2),
    (lambda s: s.startswith('array_keys('), lambda s: 'keys', 3),
    (lambda s: s.startswith('array_values('), lambda s: 'values', 3),
    (lambda s: s.startswith('array_merge('), lambda s: 'merged', 3),
    (lambda s: s.startswith('array_unique('), lambda s: 'unique', 2),
    (lambda s: s.startswith('array_search('), lambda s: 'foundKey', 2),
    (lambda s: s.startswith('array_key_exists('), lambda s: 'keyExists', 2),
    (lambda s: s.startswith('array_reverse('), lambda s: 'reversed', 2),
    (lambda s: s.startswith('array_slice('), lambda s: 'sliced', 2),
    (lambda s: s.startswith('array_splice('), lambda s: 'spliced', 2),
    # --- 通用 ---
    (lambda s: s.startswith('session_start('), lambda s: 'sessionResult', 2),
    (lambda s: s.startswith('session_id('), lambda s: 'sessionId', 3),
    (lambda s: s.startswith('memory_get_usage('), lambda s: 'memUsage', 2),
    (lambda s: s.startswith('number_format('), lambda s: 'formatted', 2),
    (lambda s: s.startswith('var_dump('), lambda s: 'dumpResult', 1),
    (lambda s: s.startswith('print_r('), lambda s: 'dumpResult', 1),
    (lambda s: s.startswith('serialize('), lambda s: 'serialized', 3),
    (lambda s: s.startswith('unserialize('), lambda s: 'unserialized', 3),
    (lambda s: s.startswith('rand('), lambda s: 'rand', 2),
    (lambda s: s.startswith('mt_rand('), lambda s: 'rand', 2),
    (lambda s: s.startswith('microtime('), lambda s: 'microtime', 2),
    # --- 布尔/比较字面量 ---
    (lambda s: s in ('true', 'false', 'TRUE', 'FALSE'), lambda s: 'flag', 2),
    (lambda s: s.startswith('!'), lambda s: 'not', 2),
    (lambda s: '==' in s or '!=' in s, lambda s: 'cond', 2),
    (lambda s: '>' in s or '<' in s or '>=' in s or '<=' in s, lambda s: 'cond', 2),
    # --- 类型转换 ---
    (lambda s: s.startswith('(bool)'), lambda s: 'cond', 3),
    (lambda s: s.startswith('(int)') or s.startswith('(integer)'), lambda s: 'num', 2),
    (lambda s: s.startswith('(float)') or s.startswith('(double)'), lambda s: 'num', 2),
    (lambda s: s.startswith('(string)'), lambda s: 'str', 2),
    (lambda s: s.startswith('(array)'), lambda s: 'arr', 2),
    (lambda s: s.startswith('(object)'), lambda s: 'obj', 2),
    # --- 字符串拼接 ---
    (lambda s: re.match(r'^["\']', s) or '. "' in s or ".'" in s, lambda s: 'str', 2),
    # --- 数值 ---
    (lambda s: re.match(r'^-?\d+\.?\d*$', s), lambda s: 'num', 1),
    # --- include/require ---
    (lambda s: s.startswith('include') or s.startswith('require'), lambda s: 'includeResult', 2),
    # --- 哨兵: 不处理 ---
    (lambda s: s.startswith('$L2x'), lambda s: None, 0),
]


_SENTINEL_PREFIX = re.compile(r'^\$L2x[89]')
_SENTINEL_CONST = re.compile(r'^\$L2xOiRy')
_SENTINEL_UNSET = re.compile(r'^\$L2xt')
_SENTINEL_GENERIC = re.compile(r'^\$L2x[0-9A-Za-z]{1,3}$')


def infer_semantic_name(var, assignments, array_keys, func_args):
    """根据变量使用模式推断语义名."""
    name = None
    c = collections.Counter()
    for src in assignments:
        for pred, name_fn, weight in RULES:
            if pred(src):
                n = name_fn(src)
                if n is not None:
                    c[n] += weight
                break
    if c:
        name = c.most_common(1)[0][0]
    if name:
        if _SENTINEL_PREFIX.match(var) or _SENTINEL_GENERIC.match(var):
            name = 'tmp'
    else:
        if _SENTINEL_CONST.match(var):
            name = 'const'
        elif _SENTINEL_UNSET.match(var):
            name = 'sentinel'
        elif _SENTINEL_PREFIX.match(var) or _SENTINEL_GENERIC.match(var):
            name = 'tmp'
        elif var.startswith('$L2xeF'):
            name = 'env'
        elif var.startswith('$L2xcVvP') or var.startswith('$L2x2Key') or var.startswith('$L2x1Key'):
            name = 'key'
        elif var.startswith('$L2xoB'):
            name = 'obj'
        elif var.startswith('$L2xBuEt'):
            name = 'buf'
        elif var.startswith('$L2xEc'):
            name = 'echo'
        elif var.startswith('$L2x'):
            name = 'val'
    return name


def analyze_variable_usage(lines):
    """分析变量使用模式, 返回 {var: {assignments:[], array_keys:[]}}。"""
    usage = {}
    for l in lines:
        for m in re.finditer(r'\$L2x\w+', l):
            v = m.group(0)
            if v not in usage:
                usage[v] = {'assignments': [], 'array_keys': []}
            rest = l[m.end():]
            am = re.match(r'\s*=\s*(.*)', rest)
            if am:
                src = am.group(1)
                src = src.split(';')[0].split(',')[0].strip()
                usage[v]['assignments'].append(src)
            for km in re.finditer(r"\$L2x\w+\[['\"]([^'\"]+)['\"]\]", l):
                if km.group(0).startswith(v):
                    usage[v]['array_keys'].append(km.group(1))
    return usage


def rewrite_file(lines, name_map):
    """对行列表应用变量名映射, 用正则边界避免误伤字符串字面量.
    \b 在 $ 前无效 ($ 不是 word 字符), 用 (?<!\\w) 替代."""
    out = []
    for l in lines:
        newl = l
        for old, new in sorted(name_map.items(), key=lambda x: -len(x[0])):
            escaped = re.escape(old)
            newl = re.sub(r'(?<!\w)' + escaped + r'\b', new, newl)
        out.append(newl)
    return out


def rename_file(inpath, outpath=None):
    """对单个 .sw.php 文件做变量语义重命名."""
    src = open(inpath).read()
    lines = src.split('\n')
    usage = analyze_variable_usage(lines)
    name_map = {}
    for var, info in usage.items():
        semantic = infer_semantic_name(
            var, info['assignments'], info['array_keys'], info.get('func_args', []))
        if semantic:
            name_map[var] = '$' + semantic
    used = {}
    final_map = {}
    for var, new in sorted(name_map.items(), key=lambda x: -len(x[0])):
        base = new
        if base in used:
            cnt = used[base] + 1
            final_map[var] = f'{base}{cnt}'
            used[base] = cnt
        else:
            final_map[var] = base
            used[base] = 1
    result = rewrite_file(lines, final_map)
    output = '\n'.join(result)
    if outpath:
        with open(outpath, 'w') as f:
            f.write(output)
    return output, final_map


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    inp = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else inp
    output, name_map = rename_file(inp, out)
    if name_map:
        print(f"重命名 {len(name_map)} 个变量: {inp} -> {out}")
        for old, new in sorted(name_map.items()): print(f"  {old} -> {new}")
    else:
        print(f"无变量重命名: {inp}")


if __name__ == '__main__':
    main()