#!/usr/bin/env bash
# PHP 反混淆工具链（合并版 v1.2）统一入口
# 用法:
#   ./deob.sh scan <源码目录>          # 步骤1: 剥壳注入（Python, batch3.py）
#   ./deob.sh dec <dec目录> <输出目录>  # 步骤2: 控制流还原（Python, full_batch.py）
#   ./deob.sh clean <glob>            # 步骤3: 清理（Python, cleanup2.py）
#   ./deob.sh switch <目录> <输出目录>  # 步骤3.5: 哨兵分发链 switch 化（Python, sentinel_deflatten.py）
#   ./deob.sh goto <目录> <输出目录>    # 步骤3.7: goto 消除（Python, goto_eliminate.py）
#   ./deob.sh verify <还原前> <还原后>  # 步骤4: 语义验证（Python, verify_semantics.py）
#   ./deob.sh phpdec <源码目录>        # 步骤0(PHP): 通用解码器扫描（PHP, deobfuscate2.php）
#   ./deob.sh rename <目录> <输出目录> # 步骤5: 变量语义重命名（Python, rename_engine.py）
#   ./deob.sh lint <目录>             # 辅助: 批量 php -l 语法检查

set -uo pipefail
TOOLS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/tools"
PHPDEC="$TOOLS_DIR/phpdec"
PHPSCRIPTS="$TOOLS_DIR/php-decoder-scripts"

php_cmd() {
    if command -v php >/dev/null 2>&1; then echo php; else
        echo "错误: 未找到 php-cli" >&2; exit 1; fi
}

cmd_scan()   { python3 "$PHPDEC/batch3.py" "${2:-.}" "${3:-wc}" "${4:-out}"; }
cmd_dec()    { python3 "$PHPDEC/full_batch.py" "${2:-decrypted}" "${3:-clean2}"; }
cmd_clean()  { python3 "$PHPDEC/cleanup2.py" "${2:-'clean2/*.deobf.php'}"; }
cmd_switch() {
    local src="${2:-clean2}" out="${3:-clean3}"
    mkdir -p "$out"
    for f in "$src"/*.deobf.php; do
        [ -e "$f" ] || { echo "错误: $src 下无 *.deobf.php"; return 1; }
        python3 "$PHPDEC/sentinel_deflatten.py" "$f" "$out/$(basename "${f%.deobf.php}").sw.php"
    done
}
cmd_goto() {
    local src="${2:-clean3}" out="${3:-clean4}"
    mkdir -p "$out"
    local count=0
    for f in "$src"/*.sw.php; do
        [ -e "$f" ] || { echo "错误: $src 下无 *.sw.php"; return 1; }
        python3 "$PHPDEC/goto_eliminate.py" "$f" "$out/$(basename "$f")"
        count=$((count + 1))
    done
    echo "goto 消除完成: $count 个文件已写入 $out/"
}
cmd_verify() { python3 "$PHPDEC/verify_semantics.py" "${2:-pre_reduce}" "${3:-clean2}"; }
cmd_rename() {
    local src="${2:-clean4}" out="${3:-clean5}"
    mkdir -p "$out"
    local total=0
    for f in "$src"/*.sw.php; do
        [ -e "$f" ] || { echo "错误: $src 下无 *.sw.php"; return 1; }
        local base; base=$(basename "$f")
        python3 "$PHPDEC/rename_engine.py" "$f" "$out/$base"
        total=$((total + 1))
    done
    echo "变量重命名完成: $total 个文件已写入 $out/"
}
cmd_phpdec() { $(php_cmd) "$PHPSCRIPTS/deobfuscate2.php" "${2:-.}"; }
cmd_lint()   { local bad=0; for f in $(find "${2:-.}" -name '*.php'); do
                   $(php_cmd) -l "$f" >/dev/null 2>&1 || { echo "语法错误: $f"; bad=1; }; done
               [ $bad -eq 0 ] && echo "全部 PHP 通过语法检查"; }

case "${1:-}" in
  scan)   cmd_scan "$@";;
  dec)    cmd_dec "$@";;
  clean)  cmd_clean "$@";;
  switch) cmd_switch "$@";;
  goto)   cmd_goto "$@";;
  verify) cmd_verify "$@";;
  rename) cmd_rename "$@";;
  phpdec) cmd_phpdec "$@";;
  lint)   cmd_lint "$@";;
  *) echo "用法: $0 {scan|dec|clean|switch|goto|verify|rename|phpdec|lint} [参数...]"; exit 1;;
esac